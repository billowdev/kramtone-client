"use strict";
exports.id = 7652;
exports.ids = [7652];
exports.modules = {

/***/ 503:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://www.kramtone.com/service/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1809:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gg": () => (/* binding */ getSession),
/* harmony export */   "jj": () => (/* binding */ getSessionServerSide),
/* harmony export */   "w7": () => (/* binding */ signOut),
/* harmony export */   "y1": () => (/* binding */ signUp),
/* harmony export */   "zB": () => (/* binding */ signIn)
/* harmony export */ });
/* unused harmony exports getProfile, updateUserById */
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(503);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// next local api
const signIn = async (user)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/auth/signin`, user, {
        baseURL: "https://www.kramtone.com/api"
    });
    return response;
};
// next local api
async function signOut() {
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/auth/signout`, {
        baseURL: "https://www.kramtone.com/api"
    });
    return response;
}
// server api
const signUp = async (user)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/auth/register", user);
    return response;
};
// next local api
const getSession = async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/auth/session`, {
        baseURL: "https://www.kramtone.com/api"
    });
    const { session , accessToken  } = response;
    return {
        ...session,
        accessToken
    };
};
const getProfile = async (token)=>{
    const { data: response  } = await axios.get(`/users/me`, {
        headers: {
            Authorization: `Bearer ${token}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};
const updateUserById = async (id, accessToken, body)=>{
    const { data: response  } = await axios.patch(`/users/${id}`, body, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};
const getSessionServerSide = async (token)=>{
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`/users/session`, {
        headers: {
            Authorization: `Bearer ${token}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7652:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BT": () => (/* binding */ fetchSession),
/* harmony export */   "Gq": () => (/* binding */ isAuthenticatedSelector),
/* harmony export */   "L3": () => (/* binding */ userRoleSelector),
/* harmony export */   "TP": () => (/* binding */ isAuthenticatingSelector),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "aF": () => (/* binding */ authSelector),
/* harmony export */   "w7": () => (/* binding */ signOut),
/* harmony export */   "zB": () => (/* binding */ signIn)
/* harmony export */ });
/* unused harmony exports signUp, updateUserProfileAction, authSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1809);
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(503);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_auth_service__WEBPACK_IMPORTED_MODULE_1__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__]);
([_services_auth_service__WEBPACK_IMPORTED_MODULE_1__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const initialState = {
    accessToken: "",
    isAuthenticated: false,
    isAuthenticating: true,
    sub: "",
    role: "",
    gid: "",
    username: ""
};
const signIn = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("auth/signin", async (credential)=>{
    const response = await _services_auth_service__WEBPACK_IMPORTED_MODULE_1__/* .signIn */ .zB(credential);
    if (response.token === "") {
        throw new Error("login failed");
    }
    _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].interceptors.request.use */ .Z.interceptors.request.use((config)=>{
        if (config && config.headers) {
            config.headers["Authorization"] = `Bearer ${response.token}`;
        }
        return config;
    });
    return response;
});
const signUp = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/signup", async (credential)=>{
    const response = await _services_auth_service__WEBPACK_IMPORTED_MODULE_1__/* .signUp */ .y1(credential);
    return response;
});
const signOut = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/signout", async ()=>{
    await _services_auth_service__WEBPACK_IMPORTED_MODULE_1__/* .signOut */ .w7();
    next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/auth/signin");
});
const updateUserProfileAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("USER/UPDATE", async ()=>{
    await _services_auth_service__WEBPACK_IMPORTED_MODULE_1__/* .signOut */ .w7();
    next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/auth/signin");
});
const fetchSession = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/fetchSession", async ()=>{
    const response = await _services_auth_service__WEBPACK_IMPORTED_MODULE_1__/* .getSession */ .Gg();
    // set access token
    if (response) {
        _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].interceptors.request.use */ .Z.interceptors.request.use((config)=>{
            if (config && config.headers && response.sub) {
                config.headers["Authorization"] = `Bearer ${response.accessToken}`;
            }
            return config;
        });
    }
    return response;
});
const authSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "auth",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchSession.fulfilled, (state, action)=>{
            state.isAuthenticating = false;
            if (action.payload.accessToken && action.payload.sub) {
                state.isAuthenticated = true;
                state.accessToken = action.payload.accessToken;
                state.sub = action.payload.sub;
                state.role = action.payload.role;
                state.gid = action.payload.gid;
            }
        });
        builder.addCase(fetchSession.rejected, (state, action)=>{
            state.accessToken = "";
            state.isAuthenticated = false;
            state.isAuthenticating = false;
            state.sub = "";
            state.gid = "";
        });
        // builder.addCase(signUp.fulfilled, (state, action) => {
        // 	state.accessToken = "";
        // 	state.email = action.payload.email;
        // 	state.username = action.payload.name;
        // 	state.isAuthenticated = false;
        // });
        builder.addCase(signIn.fulfilled, (state, action)=>{
            // state.accessToken = action.payload.token;
            // state.username = action.payload.username;
            // state.role = action.payload.role;
            state.isAuthenticated = true;
            state.isAuthenticating = false;
        });
        builder.addCase(signIn.rejected, (state, action)=>{
            state.accessToken = "";
            state.isAuthenticated = false;
            state.isAuthenticating = false;
            state.sub = "";
            state.gid = "";
        });
        builder.addCase(signOut.fulfilled, (state, action)=>{
            state.isAuthenticated = false;
            state.isAuthenticating = false;
            state.username = "";
            state.accessToken = "";
        });
    }
});
const authSelector = (store)=>store.auth;
const isAuthenticatedSelector = (store)=>store.auth.isAuthenticated;
const isAuthenticatingSelector = (store)=>store.auth.isAuthenticating;
const userRoleSelector = (store)=>store.auth.role;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;