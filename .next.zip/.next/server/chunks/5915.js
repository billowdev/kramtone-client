"use strict";
exports.id = 5915;
exports.ids = [5915];
exports.modules = {

/***/ 5915:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4746);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5018);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8539);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6983);
/* harmony import */ var _mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(32);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8792);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9801);
/* harmony import */ var _mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3787);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_ColorLens__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8507);
/* harmony import */ var _mui_icons_material_ColorLens__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ColorLens__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_Checkroom__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3694);
/* harmony import */ var _mui_icons_material_Checkroom__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Checkroom__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_Widgets__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5301);
/* harmony import */ var _mui_icons_material_Widgets__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Widgets__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3467);
/* harmony import */ var _mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7652);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(8227);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_17__, _store_store__WEBPACK_IMPORTED_MODULE_19__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_17__, _store_store__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















function GroupShopPanel({}) {
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_18__.useTheme)();
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_14___default()(theme.breakpoints.down("xs"));
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_19__/* .useAppDispatch */ .T)();
    const [openDialog, setOpenDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const handleLogout = async ()=>{
        dispatch((0,_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_17__/* .signOut */ .w7)());
        setOpenDialog(false);
    };
    const showSignOutDialog = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Dialog, {
            open: openDialog,
            keepMounted: true,
            "aria-labelledby": "alert-dialog-slide-title",
            "aria-describedby": "alert-dialog-slide-description",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogTitle, {
                    id: "alert-dialog-slide-title",
                    children: "ออกจากระบบ?"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogContentText, {
                        id: "alert-dialog-slide-description",
                        children: "คุณต้องการออกจากระบบใช่หรือไม่?"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogActions, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            onClick: ()=>setOpenDialog(false),
                            color: "info",
                            children: "ยกเลิก"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                            onClick: handleLogout,
                            color: "primary",
                            children: "ออกจากระบบ"
                        })
                    ]
                })
            ]
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {
            maxWidth: "lg",
            sx: {
                mt: 4,
                mb: 4
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                container: true,
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 12,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                            sx: {
                                p: 2,
                                display: "flex",
                                flexDirection: "row",
                                gap: "16px"
                            },
                            children: [
                                isSmallDevice ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Widgets__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    sx: {
                                        fontSize: "1.5rem",
                                        marginLeft: "8px"
                                    }
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Widgets__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    sx: {
                                        fontSize: "2.5rem",
                                        marginLeft: "16px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                    children: isSmallDevice ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        sx: {
                                            fontWeight: "bold",
                                            alignSelf: "center"
                                        },
                                        children: [
                                            " ",
                                            "ยินดีต้อนรับเข้าสู่",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            "หน้าระบบหลังบ้าน"
                                        ]
                                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        variant: "h5",
                                        sx: {
                                            fontWeight: "bold",
                                            alignSelf: "center"
                                        },
                                        children: [
                                            " ",
                                            "ยินดีต้อนรับเข้าสู่หน้าระบบหลังบ้าน",
                                            " "
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 12,
                        md: 12,
                        lg: 12,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                            sx: {
                                p: 2,
                                display: "flex",
                                flexDirection: "column",
                                height: "100%"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                    variant: "h5",
                                    gutterBottom: true,
                                    children: "เลือกเมนูที่ต้องการ"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    container: true,
                                    spacing: 2,
                                    columns: 16,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/panel/user/manage-group",
                                                icon: (_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_5___default()),
                                                text: "จัดการข้อมูลกลุ่ม"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/panel/user/manage-product",
                                                icon: (_mui_icons_material_ShoppingBag__WEBPACK_IMPORTED_MODULE_6___default()),
                                                text: "จัดการสินค้า"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/panel/user/manage-category",
                                                icon: (_mui_icons_material_Checkroom__WEBPACK_IMPORTED_MODULE_13___default()),
                                                text: "จัดการประเภทสินค้า"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/panel/user/manage-colorscheme",
                                                icon: (_mui_icons_material_ColorLens__WEBPACK_IMPORTED_MODULE_12___default()),
                                                text: "จัดการโทนสีที่มีในร้าน"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Divider, {
                                    sx: {
                                        my: 1
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    container: true,
                                    spacing: 2,
                                    columns: 16,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/manage-profile",
                                                icon: (_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_7___default()),
                                                text: "ตั้งค่าบัญชีผู้ใช้"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/",
                                                icon: (_mui_icons_material_Home__WEBPACK_IMPORTED_MODULE_16___default()),
                                                text: "กลับสู่หน้าหลักของเว็บไซต์"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Layouts_CustomMenuListItem__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                href: "/aboutus",
                                                icon: (_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_8___default()),
                                                text: "เกี่ยวกับผู้พัฒนาระบบ"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                boxShadow: 2,
                                                style: {
                                                    borderRadius: "50px",
                                                    margin: "20px 10px"
                                                },
                                                onClick: ()=>{
                                                    setOpenDialog(true);
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.ListItem, {
                                                    button: true,
                                                    classes: {
                                                        selected: "Mui-selected"
                                                    },
                                                    style: {
                                                        backgroundColor: "#FFF",
                                                        borderRadius: "50px"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Logout__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                                style: {
                                                                    color: theme.palette.grey[900]
                                                                }
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                            primary: "ออกจากระบบ",
                                                            style: {
                                                                color: theme.palette.grey[900]
                                                            }
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GroupShopPanel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;