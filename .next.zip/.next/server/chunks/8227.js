"use strict";
exports.id = 8227;
exports.ids = [8227];
exports.modules = {

/***/ 1844:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const config = {
    env: "production"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);


/***/ }),

/***/ 8599:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fj": () => (/* binding */ getOneCategory),
/* harmony export */   "KQ": () => (/* binding */ getAllCategory),
/* harmony export */   "i": () => (/* binding */ getAllCategoryByGroupId),
/* harmony export */   "k4": () => (/* binding */ createCategory),
/* harmony export */   "uu": () => (/* binding */ deleteCategory),
/* harmony export */   "yr": () => (/* binding */ updateCategory)
/* harmony export */ });
/* unused harmony export getAllCategoryByGroup */
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(503);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const getOneCategory = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/categories/get/${id}`);
    return response.payload;
};
const getAllCategoryByGroupId = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/categories/group/${id}`);
    return response.payload;
};
const getAllCategoryByGroup = async (accessToken)=>{
    const { data: response  } = await axios.get(`/categories/group`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};
const getAllCategory = async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/categories`);
    return response.payload;
};
const createCategory = async (data, accessToken)=>{
    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(`/categories`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    // const {data:response} = await axios.post(`/categories/${id}`, data, {
    // 	headers: {
    // 		Authorization: `Bearer ${accessToken}`
    // 	},
    // 	baseURL: process.env.NEXT_PUBLIC_BASE_URL_API
    // });
    console.log(response);
};
const updateCategory = async (id, data, accessToken)=>{
    // console.log('Form Data:');
    // for (const [key, value] of data.entries()) {
    // 	console.log(key, value);
    // }
    // console.log("===============")
    // console.log(id, accessToken)
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/categories/${id}`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const deleteCategory = async (id, accessToken)=>{
    await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/categories/${id}`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ec": () => (/* binding */ createColorScheme),
/* harmony export */   "KP": () => (/* binding */ getAllColorSchemeByGroupId),
/* harmony export */   "QO": () => (/* binding */ getOneColorScheme),
/* harmony export */   "Xz": () => (/* binding */ updateColorScheme),
/* harmony export */   "iF": () => (/* binding */ getAllColorScheme),
/* harmony export */   "rl": () => (/* binding */ deleteColorScheme)
/* harmony export */ });
/* unused harmony export getAllColorSchemeByGroup */
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(503);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const getOneColorScheme = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/colorschemes/get/${id}`);
    return response.payload;
};
const getAllColorSchemeByGroupId = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/colorschemes/group/${id}`);
    return response.payload;
};
const getAllColorSchemeByGroup = async (accessToken)=>{
    const { data: response  } = await axios.get(`/colorschemes/group`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};
const getAllColorScheme = async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/colorschemes`);
    return response.payload;
};
const createColorScheme = async (data, accessToken)=>{
    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(`/colorschemes`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    // const {data:response} = await axios.post(`/colorschemes/${id}`, data, {
    // 	headers: {
    // 		Authorization: `Bearer ${accessToken}`
    // 	},
    // 	baseURL: process.env.NEXT_PUBLIC_BASE_URL_API
    // });
    console.log(response);
};
const updateColorScheme = async (id, data, accessToken)=>{
    // console.log('Form Data:');
    // for (const [key, value] of data.entries()) {
    // 	console.log(key, value);
    // }
    // console.log("===============")
    // console.log(id, accessToken)
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/colorschemes/${id}`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const deleteColorScheme = async (id, accessToken)=>{
    await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/colorschemes/${id}`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6712:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BS": () => (/* binding */ getOneGroupData),
/* harmony export */   "sn": () => (/* binding */ getAllGroupData),
/* harmony export */   "st": () => (/* binding */ updateGroupData)
/* harmony export */ });
/* unused harmony exports createGroupData, deleteGroupData */
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(503);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const getOneGroupData = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/groups/get/${id}`);
    return response.payload;
};
const getAllGroupData = async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/groups/get`);
    return response.payload;
};
const createGroupData = async (data, accessToken)=>{
    await axios.post(`/groups`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const updateGroupData = async (id, data, accessToken)=>{
    // console.log('Form Data:');
    // for (const [key, value] of data.entries()) {
    // 	console.log(key, value);
    // }
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/groups/${id}`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    console.log(response);
};
const deleteGroupData = async (id)=>{
    await httpClient.delete(`/groups/${id}`, {
        baseURL: "https://www.kramtone.com/api"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5634:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fn": () => (/* binding */ increaseReloadCount),
/* harmony export */   "Ir": () => (/* binding */ deleteProduct),
/* harmony export */   "bL": () => (/* binding */ deleteProductImage),
/* harmony export */   "de": () => (/* binding */ getAllProduct),
/* harmony export */   "kN": () => (/* binding */ getAllProductByGroup),
/* harmony export */   "nM": () => (/* binding */ updateProduct),
/* harmony export */   "ry": () => (/* binding */ createProduct),
/* harmony export */   "yO": () => (/* binding */ getOneProduct)
/* harmony export */ });
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(503);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const getOneProduct = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/${id}`, {
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
    return response.payload;
};
const getAllProductByGroup = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/group/${id}`);
    return response.payload;
};
const getAllProduct = async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products`);
    return response.payload;
};
const increaseReloadCount = async (id)=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get("/products/view/" + id);
    return response.payload;
};
const createProduct = async (data, accessToken)=>{
    // 	console.log('Form Data:');
    // for (const [key, value] of data.entries()) {
    // 	console.log(key, value);
    // }
    // console.log("===============")
    await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(`/products`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const updateProduct = async (id, data, accessToken)=>{
    console.log("Form Data:");
    for (const [key, value] of data.entries()){
        console.log(key, value);
    }
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/products/${id}/data`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const deleteProduct = async (id, accessToken)=>{
    await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/products/${id}`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};
const deleteProductImage = async (productId, imageId, accessToken)=>{
    await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/products/${productId}/images/${imageId}`, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://www.kramtone.com/service/api/v1"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7692:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A1": () => (/* binding */ createCategoryAction),
/* harmony export */   "BL": () => (/* binding */ getAllCategoryByGroupAction),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "ek": () => (/* binding */ updateCategoryAction),
/* harmony export */   "uT": () => (/* binding */ categorySelector)
/* harmony export */ });
/* unused harmony exports getAllCategoryByGroupIdAction, getOneCategoryAction, deleteCategoryAction, categorySlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8599);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8227);
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(503);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_category_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__]);
([_services_category_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const initialState = {
    // message: "",
    category: {
        id: "",
        name: "",
        desc: "",
        image: "",
        isDefault: true,
        createdAt: "",
        updatedAt: ""
    },
    categoryArray: []
};
const getAllCategoryByGroupIdAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/GROUP_GET_ALL_BY_GROUP_ID", async (id)=>{
    const response = await _services_category_service__WEBPACK_IMPORTED_MODULE_1__/* .getAllCategoryByGroupId */ .i(id);
    return response;
});
const getAllCategoryByGroupAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/GROUP_GET_ALL_BY_GROUP", async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(`/categories/getAllByGroup`, {
        baseURL: "https://www.kramtone.com/api"
    });
    return response.payload;
});
const getOneCategoryAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/GET_ONE", async (id)=>{
    const response = await _services_category_service__WEBPACK_IMPORTED_MODULE_1__/* .getOneCategory */ .Fj(id);
    return response;
});
const deleteCategoryAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/DELETE", async (data)=>{
    await _services_category_service__WEBPACK_IMPORTED_MODULE_1__/* .deleteCategory */ .uu(data.id, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getOneCategoryAction(data.gid));
});
const updateCategoryAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/UPDATE", async (data)=>{
    // console.log(data)
    await _services_category_service__WEBPACK_IMPORTED_MODULE_1__/* .updateCategory */ .yr(data.id, data.body, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getAllCategoryByGroupAction());
});
const createCategoryAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("CATEGORY/CREATE", async (data)=>{
    await _services_category_service__WEBPACK_IMPORTED_MODULE_1__/* .createCategory */ .k4(data.body, data.accessToken);
// store.dispatch(getAllCategoryByGroupAction());
});
const categorySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "category",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getAllCategoryByGroupAction.fulfilled, (state, action)=>{
            state.categoryArray = action.payload;
        });
        builder.addCase(getAllCategoryByGroupAction.rejected, (state, action)=>{
            state.categoryArray = [];
        });
        builder.addCase(getAllCategoryByGroupIdAction.fulfilled, (state, action)=>{
            state.categoryArray = action.payload;
        });
        builder.addCase(getAllCategoryByGroupIdAction.rejected, (state, action)=>{
            state.categoryArray = [];
        });
        builder.addCase(getOneCategoryAction.fulfilled, (state, action)=>{
            state.category = action.payload;
        });
    // builder.addCase(createCategoryAction.rejected, (state, action) => {
    // 	state.error = action.payload
    // })
    // builder.addCase(createCategoryAction.fulfilled, (state, action) => {
    // 	state.category = action.payload
    // });
    }
});
const categorySelector = (store)=>store.category;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (categorySlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports getAllColorSchemeByGroupIdAction, getAllColorSchemeByGroupAction, getOneColorSchemeAction, deleteColorSchemeAction, updateColorSchemeAction, createColorSchemeAction, colorSchemeSlice, colorSchemeSelector */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(199);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8227);
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(503);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__]);
([_services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__, _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const initialState = {
    // message: "",
    colorScheme: {
        id: "",
        nameEN: "",
        nameTH: "",
        hex: ""
    },
    colorSchemeArray: []
};
const getAllColorSchemeByGroupIdAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/GROUP_GET_ALL_BY_GROUP_ID", async (id)=>{
    const response = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__/* .getAllColorSchemeByGroupId */ .KP(id);
    return response;
});
const getAllColorSchemeByGroupAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/GROUP_GET_ALL_BY_GROUP", async ()=>{
    const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_3__/* ["default"].get */ .Z.get(`/categories/getAllByGroup`, {
        baseURL: "https://www.kramtone.com/api"
    });
    return response.payload;
});
const getOneColorSchemeAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/GET_ONE", async (id)=>{
    const response = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__/* .getOneColorScheme */ .QO(id);
    return response;
});
const deleteColorSchemeAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/DELETE", async (data)=>{
    await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__/* .deleteColorScheme */ .rl(data.id, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getOneColorSchemeAction(data.gid));
});
const updateColorSchemeAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/UPDATE", async (data)=>{
    // console.log(data)
    await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__/* .updateColorScheme */ .Xz(data.id, data.body, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getAllColorSchemeByGroupAction());
});
const createColorSchemeAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("COLOR_SCHEME/CREATE", async (data)=>{
    await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_1__/* .createColorScheme */ .Ec(data.body, data.accessToken);
// store.dispatch(getAllColorSchemeByGroupAction());
});
const colorSchemeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "colorScheme",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getAllColorSchemeByGroupAction.fulfilled, (state, action)=>{
            state.colorSchemeArray = action.payload;
        });
        builder.addCase(getAllColorSchemeByGroupAction.rejected, (state, action)=>{
            state.colorSchemeArray = [];
        });
        builder.addCase(getAllColorSchemeByGroupIdAction.fulfilled, (state, action)=>{
            state.colorSchemeArray = action.payload;
        });
        builder.addCase(getAllColorSchemeByGroupIdAction.rejected, (state, action)=>{
            state.colorSchemeArray = [];
        });
        builder.addCase(getOneColorSchemeAction.fulfilled, (state, action)=>{
            state.colorScheme = action.payload;
        });
    // builder.addCase(createColorSchemeAction.rejected, (state, action) => {
    // 	state.error = action.payload
    // })
    // builder.addCase(createColorSchemeAction.fulfilled, (state, action) => {
    // 	state.category = action.payload
    // });
    }
});
const colorSchemeSelector = (store)=>store.colorScheme;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (colorSchemeSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8117:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pu": () => (/* binding */ getOneGroupDataAction),
/* harmony export */   "S5": () => (/* binding */ groupDataSelector),
/* harmony export */   "U2": () => (/* binding */ updateGroupDataAction),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "nW": () => (/* binding */ getAllGroupDataAction)
/* harmony export */ });
/* unused harmony export groupDataSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_group_data_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6712);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_group_data_service__WEBPACK_IMPORTED_MODULE_1__]);
_services_group_data_service__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    // message: "",
    groupData: {
        groupName: "",
        groupType: "",
        agency: "",
        logo: "",
        banner: "",
        phone: "",
        email: "",
        hno: "",
        village: "",
        lane: "",
        road: "",
        subdistrict: "",
        district: "",
        province: "",
        zipCode: "",
        lat: "",
        lng: ""
    },
    groupDataArray: []
};
const getAllGroupDataAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("GROUP_DATA/GET_ALL", async ()=>{
    const response = await _services_group_data_service__WEBPACK_IMPORTED_MODULE_1__/* .getAllGroupData */ .sn();
    return response;
});
const getOneGroupDataAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("GROUP_DATA/GET_ONE", async (id)=>{
    const response = await _services_group_data_service__WEBPACK_IMPORTED_MODULE_1__/* .getOneGroupData */ .BS(id);
    return response;
});
const updateGroupDataAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("GROUP_DATA/UPDATE", async (data)=>{
    await _services_group_data_service__WEBPACK_IMPORTED_MODULE_1__/* .updateGroupData */ .st(data.id, data.body, data.accessToken);
});
// export const createGroupDataAction = createAsyncThunk("GROUP_DATA/GET_ONE", async () => {
// 	const response = await groupDataService.createGroupData()
// 	return response.payload;
// });
const groupDataSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "groupData",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getAllGroupDataAction.fulfilled, (state, action)=>{
            state.groupDataArray = action.payload;
        });
        builder.addCase(getAllGroupDataAction.rejected, (state, action)=>{
            state.groupDataArray = [];
        });
        builder.addCase(getOneGroupDataAction.fulfilled, (state, action)=>{
            state.groupData = action.payload;
        });
        builder.addCase(getOneGroupDataAction.rejected, (state, action)=>{
            state.groupData = {
                groupName: "",
                groupType: "",
                agency: "",
                logo: "",
                banner: "",
                phone: "",
                email: "",
                hno: "",
                village: "",
                lane: "",
                road: "",
                subdistrict: "",
                district: "",
                province: "",
                zipCode: "",
                lat: "",
                lng: ""
            };
        });
    }
});
const groupDataSelector = (store)=>store.groupData;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (groupDataSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8266:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CT": () => (/* binding */ fetchPlace),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "iN": () => (/* binding */ placeSelector)
/* harmony export */ });
/* unused harmony export placeSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    // message: "",
    places: []
};
const fetchPlace = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("groupdata/fetchPlace", async ()=>{
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`https://raw.githubusercontent.com/billowdev/test-json/main/place.json`);
    console.log("====================================");
    console.log(response);
    console.log("====================================");
    return response.payload;
});
const placeSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "place",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(fetchPlace.fulfilled, (state, action)=>{
            state.places = action.payload;
        });
        builder.addCase(fetchPlace.rejected, (state, action)=>{
            state.places = [];
        });
    }
});
const placeSelector = (store)=>store.place;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (placeSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9411:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S$": () => (/* binding */ deleteProductImageAction),
/* harmony export */   "TP": () => (/* binding */ productSelector),
/* harmony export */   "XF": () => (/* binding */ getAllProductByGroupAction),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "l1": () => (/* binding */ createProductAction),
/* harmony export */   "lw": () => (/* binding */ deleteProductAction),
/* harmony export */   "w6": () => (/* binding */ updateProductAction)
/* harmony export */ });
/* unused harmony exports getOneProductAction, productSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5634);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8227);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__]);
([_services_product_service__WEBPACK_IMPORTED_MODULE_1__, _store_store__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initialState = {
    // message: "",
    product: {
        id: "",
        name: "",
        desc: "",
        price: "",
        createdAt: "",
        updatedAt: ""
    },
    productArray: []
};
// export const getAllGroupDataAction = createAsyncThunk("PRODUCT/GET_ALL", async (): Promise<any> => {
// 	const response = await productService.getAllGroupData()
// 	// console.log("===========slice===========")
// 	// console.log(response)
// 	return response;
// });
const getAllProductByGroupAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/GROUP_GET_ALL", async (id)=>{
    const response = await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .getAllProductByGroup */ .kN(id);
    return response;
});
const getOneProductAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/GET_ONE", async (id)=>{
    const response = await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .getOneProduct */ .yO(id);
    return response;
});
const deleteProductAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/DELETE", async (data)=>{
    await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .deleteProduct */ .Ir(data.id, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getOneProductAction(data.gid));
});
const deleteProductImageAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/DELETE_IMAGE", async (data)=>{
    await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .deleteProductImage */ .bL(data.productId, data.id, data.accessToken);
    const newPatchData = _store_store__WEBPACK_IMPORTED_MODULE_2__/* .store.dispatch */ .h.dispatch(getOneProductAction(data.gid));
    return newPatchData;
});
const createProductAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/CREATE", async (data)=>{
    await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .createProduct */ .ry(data.body, data.accessToken);
});
const updateProductAction = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("PRODUCT/UPDATE", async (data)=>{
    await _services_product_service__WEBPACK_IMPORTED_MODULE_1__/* .updateProduct */ .nM(data.id, data.body, data.accessToken);
});
const productSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "product",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getAllProductByGroupAction.fulfilled, (state, action)=>{
            state.productArray = action.payload;
        });
        builder.addCase(getAllProductByGroupAction.rejected, (state, action)=>{
            state.productArray = [];
        });
        builder.addCase(getOneProductAction.fulfilled, (state, action)=>{
            state.product = action.payload;
        });
        builder.addCase(getOneProductAction.rejected, (state, action)=>{
            state.product = {};
        });
    }
});
const productSelector = (store)=>store.product;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (productSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8227:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1844);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _slices_auth_slice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7652);
/* harmony import */ var _slices_place_slice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8266);
/* harmony import */ var _slices_group_data_slice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8117);
/* harmony import */ var _slices_product_slice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9411);
/* harmony import */ var _slices_category_slice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7692);
/* harmony import */ var _slices_color_scheme_slice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_slices_auth_slice__WEBPACK_IMPORTED_MODULE_3__, _slices_place_slice__WEBPACK_IMPORTED_MODULE_4__, _slices_group_data_slice__WEBPACK_IMPORTED_MODULE_5__, _slices_product_slice__WEBPACK_IMPORTED_MODULE_6__, _slices_category_slice__WEBPACK_IMPORTED_MODULE_7__, _slices_color_scheme_slice__WEBPACK_IMPORTED_MODULE_8__]);
([_slices_auth_slice__WEBPACK_IMPORTED_MODULE_3__, _slices_place_slice__WEBPACK_IMPORTED_MODULE_4__, _slices_group_data_slice__WEBPACK_IMPORTED_MODULE_5__, _slices_product_slice__WEBPACK_IMPORTED_MODULE_6__, _slices_category_slice__WEBPACK_IMPORTED_MODULE_7__, _slices_color_scheme_slice__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const reducer = {
    auth: _slices_auth_slice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
    place: _slices_place_slice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
    groupData: _slices_group_data_slice__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP,
    product: _slices_product_slice__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .ZP,
    category: _slices_category_slice__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP,
    colorScheme: _slices_color_scheme_slice__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP
};
const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer,
    devTools: _config_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"].env */ .Z.env === "development",
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware({
            serializableCheck: false
        })
});
const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;