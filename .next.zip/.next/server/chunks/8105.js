"use strict";
exports.id = 8105;
exports.ids = [8105];
exports.modules = {

/***/ 2554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C5": () => (/* binding */ isClient),
/* harmony export */   "k1": () => (/* binding */ productImageURL),
/* harmony export */   "nH": () => (/* binding */ categoryImageURL),
/* harmony export */   "vJ": () => (/* binding */ groupDataImageURL)
/* harmony export */ });
/* unused harmony exports isServer, getWindow */
const isClient = ()=>"undefined" !== "undefined";
const isServer = ()=>"undefined" === "undefined";
const getWindow = ()=>isClient() && window;
const groupDataImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/groups/images"}/${image}`;
};
const categoryImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/category/images"}/${image}`;
};
const productImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/products/images"}/${image}`;
};


/***/ }),

/***/ 8105:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7652);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2554);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__]);
_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// eslint-disable-next-line react/display-name
const withAuth = (WrappedComponent)=>(props)=>{
        // this hoc only supports client side rendering.
        if ((0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_5__/* .isClient */ .C5)()) {
            const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
            const { route  } = router;
            const isAuthenticated = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)(_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__/* .isAuthenticatedSelector */ .Gq);
            const isAuthenticating = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)(_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__/* .isAuthenticatingSelector */ .TP);
            const userRole = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)(_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_4__/* .userRoleSelector */ .L3);
            // is fetching session (eg. show spinner)
            if (isAuthenticating) {
                return null;
            }
            // If user is not logged in, return login component
            if (route !== "/auth/signin" && route !== "/auth/signup") {
                if (!isAuthenticated) {
                    router.push(`/auth/signin`);
                    return null;
                }
                if (route.startsWith("/panel/admin") && userRole !== "admin") {
                    router.push(`/404`);
                    return null;
                }
            // else if (route == "/") {
            //   router.push(`/home`); // default page after login when call root path
            //   return null;
            // }
            // If user is trying to access /panel/admin, validate user role
            // if(route === "/panel/admin" && userRole !== "admin") {
            //   router.push(`/404`);
            //   return null;
            // } else if (userRole === "admin") {
            //   router.push(`/panel/admin`);
            //   return null;
            // } else {
            //   router.push(`/`);
            //   return null;
            // }
            } else {
                if (isAuthenticated) {
                    router.push(`/panel`);
                    return null;
                }
            }
            // If user is logged in, return original component
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(WrappedComponent, {
                ...props
            });
        }
        return null;
    };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (withAuth);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;