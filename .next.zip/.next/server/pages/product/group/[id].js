(() => {
var exports = {};
exports.id = 4411;
exports.ids = [4411];
exports.modules = {

/***/ 2554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C5": () => (/* binding */ isClient),
/* harmony export */   "k1": () => (/* binding */ productImageURL),
/* harmony export */   "nH": () => (/* binding */ categoryImageURL),
/* harmony export */   "vJ": () => (/* binding */ groupDataImageURL)
/* harmony export */ });
/* unused harmony exports isServer, getWindow */
const isClient = ()=>"undefined" !== "undefined";
const isServer = ()=>"undefined" === "undefined";
const getWindow = ()=>isClient() && window;
const groupDataImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/groups/images"}/${image}`;
};
const categoryImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/category/images"}/${image}`;
};
const productImageURL = (image)=>{
    return `${"https://www.kramtone.com/service/api/v1/products/images"}/${image}`;
};


/***/ }),

/***/ 3207:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_MainLayout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8021);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5634);
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8599);
/* harmony import */ var _services_group_data_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6712);
/* harmony import */ var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(199);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2554);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3559);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_14__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_MainLayout__WEBPACK_IMPORTED_MODULE_2__, _services_product_service__WEBPACK_IMPORTED_MODULE_6__, _services_category_service__WEBPACK_IMPORTED_MODULE_7__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_8__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__]);
([_components_MainLayout__WEBPACK_IMPORTED_MODULE_2__, _services_product_service__WEBPACK_IMPORTED_MODULE_6__, _services_category_service__WEBPACK_IMPORTED_MODULE_7__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_8__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const ProductByGroupId = ({ groupId , groupData  })=>{
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_14__.useTheme)();
    const [products, setProducts] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_4___default()(theme.breakpoints.down("xs"));
    const [searchTerm, setSearchTerm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [categories, setCategories] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [selectedCategory, setSelectedCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [isModalOpen, setIsModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleBackButtonClick = ()=>{
        next_router__WEBPACK_IMPORTED_MODULE_12___default().back();
    };
    const handleOpenModal = ()=>{
        setIsModalOpen(true);
    };
    const handleCloseModal = ()=>{
        setIsModalOpen(false);
    };
    const handleCategorySelect = (category)=>{
        setSelectedCategory(category);
        setIsModalOpen(false);
    };
    const [colorSchemes, setColorSchemes] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [selectedColorScheme, setSelectedColorScheme] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [isColorSchemeModalOpen, setIsColorSchemeModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleOpenColorSchemeModal = ()=>{
        setIsColorSchemeModalOpen(true);
    };
    const handleCloseColorSchemeModal = ()=>{
        setIsColorSchemeModalOpen(false);
    };
    const handleColorSchemeSelect = (colorScheme)=>{
        setSelectedColorScheme(colorScheme);
        setIsColorSchemeModalOpen(false);
    };
    const ColorSchemeFilterModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Dialog, {
            open: isColorSchemeModalOpen,
            onClose: handleCloseColorSchemeModal,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogTitle, {
                    children: "เลือกโทนสี"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        container: true,
                        spacing: 1,
                        direction: "column",
                        children: colorSchemes.map((colorScheme, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                    onClick: ()=>handleColorSchemeSelect(colorScheme),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                            sx: {
                                                display: "inline-block",
                                                width: 50,
                                                height: 50,
                                                backgroundColor: colorScheme.hex,
                                                border: "1px solid black",
                                                marginRight: 4
                                            }
                                        }),
                                        colorScheme.id,
                                        " - ",
                                        colorScheme.hex,
                                        " - ",
                                        colorScheme.nameTH,
                                        " (",
                                        colorScheme.nameEN,
                                        ")"
                                    ]
                                })
                            }, index))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        onClick: handleCloseColorSchemeModal,
                        color: "primary",
                        children: "ยกเลิก"
                    })
                })
            ]
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        async function fetchData() {
            try {
                const payload = await _services_product_service__WEBPACK_IMPORTED_MODULE_6__/* .getAllProductByGroup */ .kN(groupId);
                const categoriesPayload = await _services_category_service__WEBPACK_IMPORTED_MODULE_7__/* .getAllCategory */ .KQ();
                const colorSchemesPayload = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_9__/* .getAllColorScheme */ .iF();
                setProducts(payload);
                setCategories(categoriesPayload);
                setColorSchemes(colorSchemesPayload);
            // setLoading(false);
            } catch (error) {
                console.error(error);
            }
        }
        fetchData();
    }, []);
    const handleSearchInputChange = (event)=>{
        setSearchTerm(event.target.value);
    };
    const handleClearFilters = ()=>{
        setSelectedCategory(null);
        setSelectedColorScheme(null);
        setSearchTerm("");
    };
    const filteredProducts = products?.filter((product)=>{
        const searchTermMatches = product.name.toLowerCase().includes(searchTerm.toLowerCase()) || product.desc.toLowerCase().includes(searchTerm.toLowerCase()) || product.price.toString().includes(searchTerm.toLowerCase()) || product.colorScheme.nameTH.toLowerCase().includes(searchTerm.toLowerCase()) || product.colorScheme.hex.toLowerCase().includes(searchTerm.toLowerCase()) || product.category.name.toLowerCase().includes(searchTerm.toLowerCase()) || product.colorScheme.nameEN.toLowerCase().includes(searchTerm.toLowerCase());
        const colorSchemeMatches = !selectedColorScheme || product.colorScheme.id === selectedColorScheme.id;
        const categoryMatches = !selectedCategory || product.category.id === selectedCategory.id;
        return searchTermMatches && categoryMatches && colorSchemeMatches;
    }) ?? [];
    const [currentPage, setCurrentPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const productsPerPage = 12;
    const indexOfLastProduct = currentPage * productsPerPage;
    const indexOfFirstProduct = indexOfLastProduct - productsPerPage;
    const currentProducts = filteredProducts.slice(indexOfFirstProduct, indexOfLastProduct);
    const totalPages = Math.ceil(filteredProducts.length / productsPerPage);
    // CategoryFilterModal component
    const CategoryFilterModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Dialog, {
            open: isModalOpen,
            onClose: handleCloseModal,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogTitle, {
                    children: "เลือกประเภทสินค้า"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        container: true,
                        spacing: 1,
                        direction: "column",
                        children: categories.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                    onClick: ()=>handleCategorySelect(category),
                                    children: category.name
                                })
                            }, index))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                        onClick: handleCloseModal,
                        color: "primary",
                        children: "ยกเลิก"
                    })
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_MainLayout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_5__.NextSeo, {
                title: "หน้าสินค้าของกลุ่มผู้ผลิต",
                description: "หน้าสินค้าทั้งหมดของกลุ่มผู้ผลิตหรือร้านค้าผ้าย้อมคราม"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                sx: {
                    flexGrow: 1,
                    p: isSmallDevice ? 1 : 5
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {
                    maxWidth: "lg",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                variant: "outlined",
                                color: "primary",
                                onClick: handleBackButtonClick,
                                children: "ย้อนกลับ"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                    variant: "h4",
                                    component: "h4",
                                    gutterBottom: true,
                                    children: [
                                        "หน้าสินค้าของกลุ่ม ",
                                        groupData?.groupName
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    container: true,
                                    spacing: {
                                        xs: 1,
                                        md: 3
                                    },
                                    justifyContent: "center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField, {
                                                label: "ค้นหาสินค้า",
                                                variant: "outlined",
                                                value: searchTerm,
                                                onChange: handleSearchInputChange,
                                                fullWidth: true,
                                                style: {
                                                    height: "100%"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenModal,
                                                fullWidth: true,
                                                style: {
                                                    height: "100%"
                                                },
                                                children: selectedCategory && selectedCategory.name !== "" ? selectedCategory.name : "กรองตามประเภทสินค้า"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenColorSchemeModal,
                                                fullWidth: true,
                                                style: {
                                                    height: "100%"
                                                },
                                                children: selectedColorScheme && selectedColorScheme.nameTH !== "" ? `${selectedColorScheme.id}-${selectedColorScheme.nameTH}` : "กรองตามโทนสี"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 2,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                variant: "outlined",
                                                color: "secondary",
                                                onClick: handleClearFilters,
                                                fullWidth: true,
                                                style: {
                                                    height: "100%"
                                                },
                                                children: "ล้างตัวกรอง"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CategoryFilterModal, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ColorSchemeFilterModal, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                            container: true,
                            spacing: 2,
                            minHeight: "100vh",
                            children: currentProducts.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                variant: "h4",
                                style: {
                                    textAlign: "center",
                                    margin: "auto"
                                },
                                children: "ไม่พบข้อมูลสินค้า"
                            }) : currentProducts.map((product, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    item: true,
                                    xs: 12,
                                    sm: 6,
                                    md: 4,
                                    lg: 3,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Card, {
                                        style: {
                                            padding: "20px",
                                            margin: "20px",
                                            maxWidth: "345"
                                        },
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CardContent, {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_10__.Carousel, {
                                                        showArrows: true,
                                                        showStatus: false,
                                                        showIndicators: false,
                                                        showThumbs: false,
                                                        emulateTouch: true,
                                                        autoPlay: true,
                                                        infiniteLoop: true,
                                                        interval: 3000,
                                                        transitionTime: 350,
                                                        swipeable: true,
                                                        dynamicHeight: true,
                                                        width: "100%",
                                                        children: product?.productImages?.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                                    src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_15__/* .productImageURL */ .k1)(image?.image),
                                                                    alt: `Product image ${index}`,
                                                                    width: "250",
                                                                    height: "250",
                                                                    style: {
                                                                        borderRadius: "5%",
                                                                        objectFit: "cover"
                                                                    }
                                                                })
                                                            }, index))
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        gutterBottom: true,
                                                        variant: "h5",
                                                        component: "div",
                                                        children: product.name
                                                    }),
                                                    product?.colorScheme ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                        container: true,
                                                        alignItems: "center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                                item: true,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                                    sx: {
                                                                        width: 50,
                                                                        height: 50,
                                                                        backgroundColor: product?.colorScheme.hex,
                                                                        borderRadius: "5%",
                                                                        border: "1px solid black",
                                                                        marginRight: 2
                                                                    }
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                                item: true,
                                                                sx: {
                                                                    marginRight: "16px"
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                    gutterBottom: true,
                                                                    component: "div",
                                                                    children: product?.colorScheme?.hex
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                                item: true,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                    gutterBottom: true,
                                                                    component: "div",
                                                                    children: product?.colorScheme?.nameTH
                                                                })
                                                            })
                                                        ]
                                                    }) : null,
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        variant: "body1",
                                                        color: "text.secondary",
                                                        children: [
                                                            "ประเภทสินค้า: ",
                                                            product?.category?.name
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        variant: "body1",
                                                        color: "text.secondary",
                                                        children: [
                                                            "โทนสี: ",
                                                            product?.colorScheme?.nameTH,
                                                            " (",
                                                            product?.colorScheme?.nameEN,
                                                            ")"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        variant: "body1",
                                                        color: "text.secondary",
                                                        children: [
                                                            "ราคา: ",
                                                            product?.price,
                                                            " THB"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                        variant: "body1",
                                                        color: "text.secondary",
                                                        children: [
                                                            "รายละเอียด : ",
                                                            product?.desc
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                variant: "contained",
                                                color: "primary",
                                                onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_12___default().push("/product/" + product.id),
                                                children: "รายละเอียดเพิ่มเติม"
                                            })
                                        ]
                                    }, product.id)
                                }, index))
                        }),
                        totalPages > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                            display: "flex",
                            justifyContent: "center",
                            mt: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Pagination, {
                                count: totalPages,
                                page: currentPage,
                                onChange: (event, value)=>setCurrentPage(value)
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    try {
        const accessToken = context.req.cookies["access_token"];
        const params = context.params;
        //   const product = await productService.getOneProduct(params?.id?.toString());
        const groupId = params?.id?.toString();
        const groupData = await _services_group_data_service__WEBPACK_IMPORTED_MODULE_8__/* .getOneGroupData */ .BS(groupId);
        return {
            props: {
                groupId,
                groupData
            }
        };
    } catch (error) {
        return {
            props: {}
        };
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductByGroupId);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 8130:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2812:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ 4176:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/icons/Menu");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 19:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Box");

/***/ }),

/***/ 4960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 4508:
/***/ ((module) => {

"use strict";
module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

"use strict";
module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,2636,5675,7652,8227,8021], () => (__webpack_exec__(3207)));
module.exports = __webpack_exports__;

})();