"use strict";
(() => {
var exports = {};
exports.id = 6289;
exports.ids = [6289,2894];
exports.modules = {

/***/ 3063:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4746);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8227);
/* harmony import */ var _store_slices_category_slice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7692);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6902);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8105);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1809);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6516);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_17__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _store_slices_category_slice__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_auth_service__WEBPACK_IMPORTED_MODULE_12__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _store_slices_category_slice__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_auth_service__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















// import EditDialog from "./components"

const Transition = /*#__PURE__*/ (/* unused pure expression or super */ null && (React.forwardRef(function Transition(props, ref) {
    return /*#__PURE__*/ _jsx(Slide, {
        direction: "up",
        ref: ref,
        ...props
    });
})));
const useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_17__.makeStyles)({
    customToolbar: {
        position: "relative"
    },
    addButton: {
        position: "absolute",
        top: 10,
        right: 10
    },
    toolbar: {
        display: "flex",
        justifyContent: "space-between"
    },
    formControl: {
        minWidth: 120,
        marginRight: 2
    },
    tableContainer: {
        paddingTop: "20px",
        paddingLeft: "20px",
        marginTop: "20px",
        marginLeft: "20px",
        width: "80%",
        height: "100%"
    }
});
const CustomToolbar = ({ setFilterButtonEl  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__.GridToolbarContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__.GridToolbarColumnsButton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__.GridToolbarDensitySelector, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__.GridToolbarFilterButton, {
                ref: setFilterButtonEl
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                href: "/panel/user/manage-category/add",
                passHref: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Fab, {
                    color: "primary",
                    "aria-label": "add",
                    sx: {
                        position: "absolute",
                        top: 10,
                        right: 10
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9___default()), {})
                })
            })
        ]
    });
function UserPanelManageCategory({ accessToken  }) {
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__.useTheme)();
    const classes = useStyles();
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const categoryData = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useSelector)(_store_slices_category_slice__WEBPACK_IMPORTED_MODULE_4__/* .categorySelector */ .uT);
    const [openAddDialog, setOpenAddDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [openDeleteDialog, setOpenDeleteDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [openEditDialog, setOpenEditDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [selectedCategory, setSelectedCategory] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [searchTerm, setSearchTerm] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [filter, setFilter] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [page, setPage] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const [rowsPerPage, setRowsPerPage] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(10);
    const handleChangePage = (event, newPage)=>{
        setPage(newPage);
    };
    const handleChangeRowsPerPage = (event)=>{
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        dispatch((0,_store_slices_category_slice__WEBPACK_IMPORTED_MODULE_4__/* .getAllCategoryByGroupAction */ .BL)());
    }, [
        dispatch
    ]);
    const [filterButtonEl, setFilterButtonEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleDeleteConfirm = ()=>{
        if (selectedCategory) {
            //     const sid = selectedCategory.id
            //     // dispatch(deleteCategoryAction({id:sid, gid}!))
            console.log(selectedCategory);
        }
        setOpenDeleteDialog(false);
    };
    const handleDeleteCancel = ()=>{
        setOpenDeleteDialog(false);
    };
    const handleEditConfirm = ()=>{
        if (selectedCategory) {
            console.log(selectedCategory);
        }
        setOpenEditDialog(false);
    };
    const handleEditCancel = ()=>{
        setOpenEditDialog(false);
    };
    const handleAddClick = (event)=>{
        setOpenAddDialog(true);
    };
    const handleAddConfirm = (product)=>{
        console.log(product);
    };
    const handleAddCancel = ()=>{
        setOpenAddDialog(false);
    };
    const handleDeleteClick = (e, row)=>{
        setOpenDeleteDialog(true);
    };
    const showEditDialog = ()=>{
        if (selectedCategory === null) {
            return;
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Dialog, {
            open: openEditDialog,
            keepMounted: true,
            "aria-labelledby": "alert-dialog-slide-title",
            "aria-describedby": "alert-dialog-slide-description",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.DialogTitle, {
                    id: "alert-dialog-slide-title",
                    children: [
                        "Confirm to delete the product? : ",
                        selectedCategory.name
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.DialogContent, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.DialogActions, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Button, {
                            onClick: ()=>setOpenEditDialog(false),
                            color: "info",
                            children: "Cancel"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Button, {
                            onClick: handleEditConfirm,
                            color: "primary",
                            children: "Edit"
                        })
                    ]
                })
            ]
        });
    };
    const columns = [
        {
            field: "name",
            editable: true,
            headerName: "ชื่อโหนด",
            width: 180
        },
        {
            field: "desc",
            editable: true,
            headerName: "รายละเอียด",
            width: 180
        },
        {
            headerName: "การดำเนินการ",
            field: ".",
            width: 180,
            renderCell: ({ row  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Stack, {
                    direction: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.IconButton, {
                            "aria-label": "delete",
                            size: "large",
                            onClick: ()=>{
                                setSelectedCategory(row);
                                setOpenDeleteDialog(true);
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default()), {
                                fontSize: "inherit"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.IconButton, {
                            "aria-label": "edit",
                            size: "large",
                            onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/panel/user/manage-category/edit?id=" + row.id),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6___default()), {
                                fontSize: "inherit"
                            })
                        })
                    ]
                })
        }
    ];
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_16___default()(theme.breakpoints.down("xs"));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_15__.Container, {
                sx: {
                    marginLeft: isSmallDevice ? 0 : 2,
                    marginTop: isSmallDevice ? 0 : 4
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_14__.DataGrid, {
                    sx: {
                        backgroundColor: "white",
                        height: "100vh",
                        width: "80vw"
                    },
                    rows: categoryData?.categoryArray ?? [],
                    columns: columns,
                    // pageSize={25}
                    // rowsPerPageOptions={[25]}
                    components: {
                        Toolbar: CustomToolbar
                    },
                    componentsProps: {
                        panel: {
                            anchorEl: filterButtonEl
                        },
                        toolbar: {
                            setFilterButtonEl
                        }
                    }
                })
            }),
            showEditDialog()
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(UserPanelManageCategory));
const getServerSideProps = async (context)=>{
    try {
        const accessToken = context.req.cookies["access_token"];
        const { gid  } = await _services_auth_service__WEBPACK_IMPORTED_MODULE_12__/* .getSessionServerSide */ .jj(accessToken);
        // const productArray = await categoryService.getAllProductByGroup(gid)
        return {
            props: {
                gid,
                accessToken
            }
        };
    } catch (error) {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2812:
/***/ ((module) => {

module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ 6146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3694:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 3188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 6902:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 8539:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 6516:
/***/ ((module) => {

module.exports = require("@mui/x-data-grid");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,7652,8227,4746,8105], () => (__webpack_exec__(3063)));
module.exports = __webpack_exports__;

})();