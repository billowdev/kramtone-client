(() => {
var exports = {};
exports.id = 9075;
exports.ids = [9075,2894];
exports.modules = {

/***/ 270:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4746);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8227);
/* harmony import */ var _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9411);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6902);
/* harmony import */ var _mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6146);
/* harmony import */ var _mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8105);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5634);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1809);
/* harmony import */ var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(199);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8792);
/* harmony import */ var _mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(7738);
/* harmony import */ var _mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(2554);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(3559);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_product_service__WEBPACK_IMPORTED_MODULE_12__, _services_auth_service__WEBPACK_IMPORTED_MODULE_13__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_3__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_product_service__WEBPACK_IMPORTED_MODULE_12__, _services_auth_service__WEBPACK_IMPORTED_MODULE_13__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















// import EditDialog from "./components"

const Transition = /*#__PURE__*/ (/* unused pure expression or super */ null && (React.forwardRef(function Transition(props, ref) {
    return /*#__PURE__*/ _jsx(Slide, {
        direction: "up",
        ref: ref,
        ...props
    });
})));





const useStyles = (0,_material_ui_core__WEBPACK_IMPORTED_MODULE_20__.makeStyles)({
    customToolbar: {
        position: "relative"
    },
    addButton: {
        position: "absolute",
        top: 10,
        right: 10
    },
    toolbar: {
        display: "flex",
        justifyContent: "space-between"
    },
    formControl: {
        minWidth: 120,
        marginRight: 2
    },
    tableContainer: {
        paddingTop: "20px",
        paddingLeft: "20px",
        marginTop: "20px",
        marginLeft: "20px",
        width: "80%",
        height: "100%"
    }
});
const CustomToolbar = ({ setFilterButtonEl  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__.GridToolbarContainer, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__.GridToolbarColumnsButton, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__.GridToolbarDensitySelector, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__.GridToolbarFilterButton, {
                ref: setFilterButtonEl
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                href: "/panel/user/manage-product/add",
                passHref: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Fab, {
                    color: "primary",
                    "aria-label": "add",
                    sx: {
                        position: "absolute",
                        top: 10,
                        right: 10
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Add__WEBPACK_IMPORTED_MODULE_9___default()), {})
                })
            })
        ]
    });
function UserPanelManageCategory({ accessToken , gid , productArray  }) {
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_11__.useTheme)();
    // const classes = useStyles();
    const [productData, setProductData] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(productArray);
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_3__/* .useAppDispatch */ .T)();
    const prodductData = (0,react_redux__WEBPACK_IMPORTED_MODULE_16__.useSelector)(_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__/* .productSelector */ .TP);
    const [openDeleteDialog, setOpenDeleteDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [openEditDialog, setOpenEditDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const [selectedCategory, setSelectedCategory] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        dispatch((0,_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__/* .getAllProductByGroupAction */ .XF)(gid));
    }, [
        dispatch
    ]);
    const [filterButtonEl, setFilterButtonEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleDeleteConfirm = ()=>{
        if (selectedCategory) {
            //     const sid = selectedCategory.id
            //     // dispatch(deleteCategoryAction({id:sid, gid}!))
            console.log(selectedCategory);
        }
        setOpenDeleteDialog(false);
    };
    const handleEditConfirm = ()=>{
        if (selectedCategory) {
            console.log(selectedCategory);
        }
        setOpenEditDialog(false);
    };
    const showEditDialog = ()=>{
        if (selectedCategory === null) {
            return;
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Dialog, {
            open: openEditDialog,
            keepMounted: true,
            "aria-labelledby": "alert-dialog-slide-title",
            "aria-describedby": "alert-dialog-slide-description",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__.DialogTitle, {
                    id: "alert-dialog-slide-title",
                    children: [
                        "Confirm to delete the product? : ",
                        selectedCategory.name
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.DialogContent, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__.DialogActions, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Button, {
                            onClick: ()=>setOpenEditDialog(false),
                            color: "info",
                            children: "Cancel"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Button, {
                            onClick: handleEditConfirm,
                            color: "primary",
                            children: "Edit"
                        })
                    ]
                })
            ]
        });
    };
    const columns = [
        {
            field: "name",
            editable: true,
            headerName: "ชื่อโหนด",
            width: 180
        },
        {
            field: "desc",
            editable: true,
            headerName: "รายละเอียด",
            width: 180
        },
        {
            field: "price",
            headerName: "ราคา",
            width: 180
        },
        {
            field: "colorScheme",
            headerName: "โทนสี",
            width: 100,
            renderCell: ({ value  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Box, {
                    sx: {
                        width: 50,
                        height: 50,
                        backgroundColor: value?.hex,
                        borderRadius: "50%",
                        border: "1px solid black",
                        marginLeft: 2
                    }
                })
        },
        {
            field: "productImages",
            headerName: "รูปภาพ",
            width: 200,
            renderCell: (params)=>{
                const images = params.value.map((image)=>(0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_25__/* .productImageURL */ .k1)(image.image));
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_23__.Carousel, {
                    showArrows: true,
                    showStatus: false,
                    showIndicators: false,
                    showThumbs: false,
                    emulateTouch: true,
                    autoPlay: true,
                    infiniteLoop: true,
                    interval: 3000,
                    transitionTime: 350,
                    swipeable: true,
                    dynamicHeight: true,
                    width: "100%",
                    children: images.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_21___default()), {
                            src: image,
                            height: 70,
                            width: 100,
                            alt: `Product image ${index}`,
                            style: {
                                borderRadius: "5%"
                            }
                        }, index))
                });
            }
        },
        {
            headerName: "การดำเนินการ",
            field: ".",
            width: 180,
            renderCell: ({ row  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Stack, {
                    direction: "row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.IconButton, {
                            "aria-label": "ลบข้อมูล",
                            size: "large",
                            onClick: ()=>{
                                sweetalert2__WEBPACK_IMPORTED_MODULE_22___default().fire({
                                    title: "ลบสินค้า",
                                    text: "เมื่อลบแล้วไม่สามารถกู้คืนได้!",
                                    icon: "warning",
                                    showCancelButton: true,
                                    cancelButtonText: "ยกเลิก",
                                    confirmButtonText: "ยืนยันการลบ",
                                    reverseButtons: true
                                }).then((result)=>{
                                    if (result.isConfirmed) {
                                        // Dispatch the deleteProductAction here
                                        dispatch((0,_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_4__/* .deleteProductAction */ .lw)({
                                            id: row.id,
                                            accessToken
                                        }));
                                        sweetalert2__WEBPACK_IMPORTED_MODULE_22___default().fire("ลบข้อมูลเรียบร้อย!", "สินค้าของคุณถูกลบเรียบร้อยแล้ว", "success").then(()=>{
                                            setTimeout(()=>{
                                                window.location.reload(); // Reload the page after 2 seconds
                                            }, 200);
                                        });
                                    }
                                });
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_7___default()), {
                                fontSize: "inherit"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.IconButton, {
                            "aria-label": "แก้ไขข้อมูล",
                            size: "large",
                            onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/panel/user/manage-product/edit?id=" + row.id),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Edit__WEBPACK_IMPORTED_MODULE_6___default()), {
                                fontSize: "inherit"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.IconButton, {
                            "aria-label": "ดูข้อมูล",
                            size: "large",
                            onClick: ()=>next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/panel/user/manage-product/" + row.id),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Info__WEBPACK_IMPORTED_MODULE_15___default()), {
                                fontSize: "inherit"
                            })
                        })
                    ]
                })
        }
    ];
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_19___default()(theme.breakpoints.down("xs"));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_18__.Container, {
                sx: {
                    marginLeft: isSmallDevice ? 0 : 2,
                    marginTop: isSmallDevice ? 0 : 4
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_x_data_grid__WEBPACK_IMPORTED_MODULE_17__.DataGrid, {
                    sx: {
                        backgroundColor: "white",
                        height: "100vh",
                        width: "80vw"
                    },
                    rows: productData ?? [],
                    columns: columns,
                    // pageSize={25}
                    // rowsPerPageOptions={[25]}
                    components: {
                        Toolbar: CustomToolbar
                    },
                    componentsProps: {
                        panel: {
                            anchorEl: filterButtonEl
                        },
                        toolbar: {
                            setFilterButtonEl
                        }
                    }
                })
            }),
            showEditDialog()
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(UserPanelManageCategory));
const getServerSideProps = async (context)=>{
    try {
        const accessToken = context.req.cookies["access_token"];
        const { gid  } = await _services_auth_service__WEBPACK_IMPORTED_MODULE_13__/* .getSessionServerSide */ .jj(accessToken);
        const productArray = await _services_product_service__WEBPACK_IMPORTED_MODULE_12__/* .getAllProductByGroup */ .kN(gid);
        const colorschemes = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__/* .getAllColorScheme */ .iF();
        return {
            props: {
                gid,
                accessToken,
                productArray,
                colorschemes
            }
        };
    } catch (error) {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 8130:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2812:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ 6146:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 3694:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 3188:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 6902:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Edit");

/***/ }),

/***/ 8539:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 7934:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1431:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 7738:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/x-data-grid");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 4508:
/***/ ((module) => {

"use strict";
module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

"use strict";
module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,2636,5675,7652,8227,4746,8105], () => (__webpack_exec__(270)));
module.exports = __webpack_exports__;

})();