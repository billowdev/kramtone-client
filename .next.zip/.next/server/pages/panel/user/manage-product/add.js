"use strict";
(() => {
var exports = {};
exports.id = 7093;
exports.ids = [7093];
exports.modules = {

/***/ 2097:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4746);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8105);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9411);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8227);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6201);
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8599);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1809);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2105);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(199);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_5__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_8__, _store_store__WEBPACK_IMPORTED_MODULE_9__, react_hot_toast__WEBPACK_IMPORTED_MODULE_10__, _services_category_service__WEBPACK_IMPORTED_MODULE_11__, _services_auth_service__WEBPACK_IMPORTED_MODULE_12__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_5__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_8__, _store_store__WEBPACK_IMPORTED_MODULE_9__, react_hot_toast__WEBPACK_IMPORTED_MODULE_10__, _services_category_service__WEBPACK_IMPORTED_MODULE_11__, _services_auth_service__WEBPACK_IMPORTED_MODULE_12__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const AddProductForm = ({ accessToken , categories , gid , colorSchemes  })=>{
    const [selectedCategory, setSelectedCategory] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        id: "",
        name: "",
        desc: "",
        image: "default_image.png"
    });
    const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_9__/* .useAppDispatch */ .T)();
    const initialValues = {
        name: "",
        desc: "",
        price: "",
        images: undefined
    };
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const [addValue, setAddValue] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(initialValues);
    const [images, setImages] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [previewImages, setPreviewImages] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const handleImageChange = (event, setFieldValue, values)=>{
        if (event.target.files && event.target.files.length > 0) {
            const files = event.target.files;
            const urls = [];
            for(let i = 0; i < files.length; i++){
                urls.push(URL.createObjectURL(files[i]));
            }
            setPreviewImages((prevPreviewImages)=>[
                    ...prevPreviewImages,
                    ...urls
                ]);
            const existingFiles = values.images || [];
            // setFieldValue('images', [...existingFiles, ...files]);
            setImages((prevImages)=>[
                    ...prevImages,
                    ...files
                ]); // add new image files to state
        }
    };
    const colorSchemeModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
            open: colorShemeModalOpen,
            keepMounted: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                    children: "กรุณาเลือกโทนสี"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.List, {
                        children: colorSchemes && colorSchemes.map((colorScheme)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItem, {
                                button: true,
                                onClick: ()=>handleSelectColorScheme(colorScheme),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                        primary: colorScheme.nameTH,
                                        secondary: colorScheme.hex
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: 50,
                                            height: 50,
                                            backgroundColor: colorScheme.hex,
                                            borderRadius: "50%",
                                            border: "1px solid black",
                                            marginLeft: 2
                                        }
                                    })
                                ]
                            }, colorScheme.id))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleCloseColorSchemeModal,
                        children: "Cancel"
                    })
                })
            ]
        });
    };
    const handleSelectCategory = (category)=>{
        setSelectedCategory(category);
        setModalOpen(false);
    };
    const handleOpenModal = ()=>{
        setModalOpen(true);
    };
    const handleCloseModal = ()=>{
        setModalOpen(false);
    };
    const [selectedColorScheme, setSelectedColorScheme] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        id: "",
        nameEN: "",
        nameTH: "กรุณาเลือกโทนสีสำหรับสินค้า",
        hex: ""
    });
    const [colorShemeModalOpen, setColorSchemeModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const handleSelectColorScheme = (colorScheme)=>{
        setSelectedColorScheme(colorScheme);
        setColorSchemeModalOpen(false);
    };
    const handleOpenColorSchemeModal = ()=>{
        setColorSchemeModalOpen(true);
    };
    const handleCloseColorSchemeModal = ()=>{
        setColorSchemeModalOpen(false);
    };
    const handleSubmit = async (values)=>{
        try {
            const formData = new FormData();
            if (images) {
                for(let i = 0; i < images.length; i++){
                    formData.append("images", images[i]);
                }
            }
            formData.append("product", JSON.stringify({
                name: values.name,
                desc: values.desc,
                price: values.price,
                categoryId: selectedCategory && selectedCategory?.id,
                groupId: gid,
                colorSchemeId: selectedColorScheme && selectedColorScheme?.id
            }));
            const result = await sweetalert2__WEBPACK_IMPORTED_MODULE_15___default().fire({
                title: "เพิ่มข้อมูล?",
                text: `คุณต้องการเพิ่มข้อมูลสินค้า ${values.name}`,
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "ใช่, ยืนยัน!",
                cancelButtonText: "ไม่, ยกเลิก"
            });
            if (result.isConfirmed) {
                const createStatus = await dispatch((0,_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_8__/* .createProductAction */ .l1)({
                    body: formData,
                    accessToken
                }));
                if (createStatus.meta.requestStatus === "fulfilled") {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].success("เพิ่มข้อมูลประเภทสินค้าสำเร็จ");
                    router.push("/panel/user/manage-product");
                } else {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].error("เพิ่มข้อมูลประเภทสินค้าไม่สำเร็จ โปรดลองอีกครั้ง");
                }
            }
        } catch (error) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].error("เพิ่มข้อมูลประเภทสินค้าไม่สำเร็จ");
            console.error("An error occurred:", error);
        // Handle the error here
        }
    };
    const categoryModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
            open: modalOpen,
            keepMounted: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                    children: "กรุณาเลือกประเภทสินค้า"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.List, {
                        children: categories && categories.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItem, {
                                button: true,
                                onClick: ()=>handleSelectCategory(category),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                    primary: category.name
                                })
                            }, category.id))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleCloseModal,
                        children: "Cancel"
                    })
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
                initialValues: initialValues,
                validate: (values)=>{
                    let errors = {};
                    if (!values.name) errors.name = "กรุณากรอกชื่อสินค้า";
                    if (!values.desc) errors.desc = "กรุณากรอกรายละเอียดสินค้า";
                    if (!values.price) errors.price = "กรุณากรอกราคาสินค้า";
                    return errors;
                },
                onSubmit: (values, { setSubmitting  })=>{
                    // setAddValue(values)
                    handleSubmit(values); // call handleSubmit function here
                    setSubmitting(false);
                },
                children: ({ values , handleChange , handleBlur , isSubmitting , setFieldValue  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
                                    sx: {
                                        padding: 4
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                            gutterBottom: true,
                                            variant: "h3",
                                            children: "เพิ่มข้อมูลสินค้า"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "name",
                                            type: "text",
                                            label: "ชื่อสินค้า",
                                            value: values.name,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "desc",
                                            type: "string",
                                            label: "รายละเอียดสินค้า",
                                            value: values.desc,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "price",
                                            type: "number",
                                            label: "ราคาสินค้า",
                                            value: values.price,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenModal,
                                                children: selectedCategory && selectedCategory.name !== "" ? selectedCategory.name : "เลือกประเภทสินค้า"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenColorSchemeModal,
                                                children: [
                                                    selectedColorScheme ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                        sx: {
                                                            width: 50,
                                                            height: 50,
                                                            backgroundColor: selectedColorScheme.hex,
                                                            borderRadius: "50%",
                                                            border: "1px solid black",
                                                            marginRight: 2
                                                        }
                                                    }) : null,
                                                    selectedColorScheme ? `${selectedColorScheme.nameTH} / ${selectedColorScheme.nameEN} / ${selectedColorScheme.hex}  ` : "เลือกโทนสี"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "file",
                                                    onChange: (event)=>handleImageChange(event, setFieldValue, values),
                                                    name: "images",
                                                    multiple: true,
                                                    accept: "image/*",
                                                    id: "files",
                                                    style: {
                                                        display: "none"
                                                    }
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                    htmlFor: "files",
                                                    style: {
                                                        display: "flex",
                                                        alignItems: "center",
                                                        cursor: "pointer"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_13__.CloudUpload, {
                                                            style: {
                                                                marginRight: 10
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            style: {
                                                                color: "#00B0CD"
                                                            },
                                                            children: "เพิ่มรูปภาพ"
                                                        })
                                                    ]
                                                }),
                                                previewImages.map((url, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        style: {
                                                            position: "relative",
                                                            display: "inline-block"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                src: url,
                                                                alt: "preview",
                                                                style: {
                                                                    maxWidth: 150,
                                                                    maxHeight: 150,
                                                                    margin: 10
                                                                }
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: ()=>{
                                                                    const newImages = [
                                                                        ...images
                                                                    ];
                                                                    newImages.splice(index, 1);
                                                                    setImages(newImages);
                                                                    const newPreviews = [
                                                                        ...previewImages
                                                                    ];
                                                                    newPreviews.splice(index, 1);
                                                                    setPreviewImages(newPreviews);
                                                                },
                                                                style: {
                                                                    position: "absolute",
                                                                    top: 0,
                                                                    right: 0,
                                                                    backgroundColor: "transparent",
                                                                    border: "none",
                                                                    color: "red",
                                                                    cursor: "pointer"
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_13__.Delete, {
                                                                    style: {
                                                                        color: "red"
                                                                    }
                                                                })
                                                            })
                                                        ]
                                                    }, index))
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardActions, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                            disabled: isSubmitting,
                                            fullWidth: true,
                                            variant: "contained",
                                            color: "primary",
                                            // onClick={handleOpenQuestionConfirm}
                                            type: "submit",
                                            sx: {
                                                marginRight: 1
                                            },
                                            children: "เพิ่ม"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/panel/user/manage-product",
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                fullWidth: true,
                                                children: "ยกเลิก"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
            }),
            categoryModal(),
            colorSchemeModal()
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(AddProductForm));
const getServerSideProps = async (context)=>{
    const accessToken = context.req.cookies["access_token"] || "";
    const { gid  } = await _services_auth_service__WEBPACK_IMPORTED_MODULE_12__/* .getSessionServerSide */ .jj(accessToken);
    const categories = await _services_category_service__WEBPACK_IMPORTED_MODULE_11__/* .getAllCategory */ .KQ();
    const colorSchemes = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_14__/* .getAllColorScheme */ .iF();
    if (accessToken) {
        return {
            props: {
                categories,
                accessToken,
                gid,
                colorSchemes
            }
        };
    } else {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 3694:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 8539:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,7652,8227,4746,8105], () => (__webpack_exec__(2097)));
module.exports = __webpack_exports__;

})();