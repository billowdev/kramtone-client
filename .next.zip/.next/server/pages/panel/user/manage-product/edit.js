(() => {
var exports = {};
exports.id = 1294;
exports.ids = [1294];
exports.modules = {

/***/ 7482:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4746);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8105);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9411);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8227);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6201);
/* harmony import */ var _services_category_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8599);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1809);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2105);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(199);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _services_product_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5634);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(2554);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3559);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_5__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_9__, _store_store__WEBPACK_IMPORTED_MODULE_10__, react_hot_toast__WEBPACK_IMPORTED_MODULE_11__, _services_category_service__WEBPACK_IMPORTED_MODULE_12__, _services_auth_service__WEBPACK_IMPORTED_MODULE_13__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_15__, _services_product_service__WEBPACK_IMPORTED_MODULE_17__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__, _components_withAuth__WEBPACK_IMPORTED_MODULE_5__, _store_slices_product_slice__WEBPACK_IMPORTED_MODULE_9__, _store_store__WEBPACK_IMPORTED_MODULE_10__, react_hot_toast__WEBPACK_IMPORTED_MODULE_11__, _services_category_service__WEBPACK_IMPORTED_MODULE_12__, _services_auth_service__WEBPACK_IMPORTED_MODULE_13__, _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_15__, _services_product_service__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

























const AddProductForm = ({ accessToken , categories , gid , product , colorschemes  })=>{
    const [selectedCategory, setSelectedCategory] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        id: product?.category?.id,
        name: product?.category?.name,
        desc: "",
        image: "default_image.png"
    });
    const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_20__.useTheme)();
    const [selectedColorScheme, setSelectedColorScheme] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        id: product?.colorScheme?.id,
        nameEN: product?.colorScheme?.nameEN,
        nameTH: product?.colorScheme?.nameTH,
        hex: product?.colorScheme?.hex
    });
    const [colorShemeModalOpen, setColorSchemeModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_10__/* .useAppDispatch */ .T)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const [previewImages, setPreviewImages] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [images, setImages] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)([]);
    const [existingImages, setExistingImages] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(product?.productImages);
    const [selectedImage, setSelectedImage] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(null);
    // Pass the product object as a prop to this component
    const initialValues = {
        name: product?.name,
        desc: product?.desc,
        price: product?.price,
        images: undefined
    };
    const [updateValue, setUpdateValue] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(initialValues);
    const handleUpdate = async (values)=>{
        try {
            const formData = new FormData();
            if (images) {
                for(let i = 0; i < images.length; i++){
                    formData.append("images", images[i]);
                }
            }
            formData.append("product", JSON.stringify({
                name: values.name,
                desc: values.desc,
                price: values.price,
                categoryId: selectedCategory && selectedCategory?.id,
                colorSchemeId: selectedColorScheme && selectedColorScheme?.id
            }));
            const result = await sweetalert2__WEBPACK_IMPORTED_MODULE_16___default().fire({
                title: "แก้ไขข้อมูล?",
                text: `คุณต้องการแก้ไขข้อมูลสินค้า ${values.name}`,
                icon: "question",
                showCancelButton: true,
                confirmButtonText: "ใช่, ยืนยัน!",
                cancelButtonText: "ไม่, ยกเลิก"
            });
            if (result.isConfirmed) {
                const updateStatus = await dispatch((0,_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_9__/* .updateProductAction */ .w6)({
                    id: product?.id,
                    body: formData,
                    accessToken
                }));
                if (updateStatus.meta.requestStatus === "fulfilled") {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_11__["default"].success("แก้ไขข้อมูลสินค้าสำเร็จ");
                    // console.log(updateStatus)
                    router.push("/panel/user/manage-product");
                } else {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_11__["default"].error("แก้ไขข้อมูลสินค้าไม่สำเร็จ โปรดลองอีกครั้ง");
                }
            }
        } catch (error) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_11__["default"].error("แก้ไขข้อมูลสินค้าไม่สำเร็จ");
            console.error("An error occurred:", error);
        // Handle the error here
        }
    };
    const handleImageChange = (event)=>{
        const files = event.target.files;
        if (files) {
            setImages([
                ...images,
                ...Array.from(files)
            ]);
            const urls = [];
            const length = files.length;
            for(let i = 0; i < length; i++){
                urls.push(URL.createObjectURL(files[i]));
            }
            setPreviewImages((prevPreviewImages)=>[
                    ...prevPreviewImages,
                    ...urls
                ]);
        }
    };
    const handleDeleteImage = (index)=>{
        const newPreviewImages = [
            ...previewImages
        ];
        newPreviewImages.splice(index, 1);
        setPreviewImages(newPreviewImages);
        const newImages = [
            ...images
        ];
        newImages.splice(index, 1);
        setImages(newImages);
    };
    const handleDeleteExistImage = async (image)=>{
        const { id  } = image;
        // await dispatch(deleteProductImageAction({ productId: product?.id, id, accessToken, gid }));
        // const updatedImages = existingImages.filter((image: any) => image.id !== id);
        // setExistingImages(updatedImages);
        const result = await sweetalert2__WEBPACK_IMPORTED_MODULE_16___default().fire({
            title: "ลบรูปภาพ",
            text: "เมื่อลบแล้วไม่สามารถกู้คืนได้!",
            icon: "warning",
            showCancelButton: true,
            cancelButtonText: "ยกเลิก",
            confirmButtonText: "ยืนยันการลบ",
            reverseButtons: true
        });
        if (result.isConfirmed) {
            // Call the API or function to delete the image
            // await deleteImage(id);
            await dispatch((0,_store_slices_product_slice__WEBPACK_IMPORTED_MODULE_9__/* .deleteProductImageAction */ .S$)({
                productId: product?.id,
                id,
                accessToken,
                gid
            }));
            sweetalert2__WEBPACK_IMPORTED_MODULE_16___default().fire("ลบข้อมูลเรียบร้อย!", "รูปภาพของคุณถูกลบเรียบร้อยแล้ว", "success");
            const updatedImages = existingImages.filter((image)=>image.id !== id);
            setExistingImages(updatedImages);
        }
    };
    const handleSelectCategory = (category)=>{
        setSelectedCategory(category);
        setModalOpen(false);
    };
    const handleOpenModal = ()=>{
        setModalOpen(true);
    };
    const handleCloseModal = ()=>{
        setModalOpen(false);
    };
    const handleSelectColorScheme = (colorScheme)=>{
        setSelectedColorScheme(colorScheme);
        setColorSchemeModalOpen(false);
    };
    const handleOpenColorSchemeModal = ()=>{
        setColorSchemeModalOpen(true);
    };
    const handleCloseColorSchemeModal = ()=>{
        setColorSchemeModalOpen(false);
    };
    const [openDialog, setOpenDialog] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const isLargeDevice = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.up("lg"));
    const showPreviewImage = (values)=>{
        if (values.file_obj) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                alt: "product image",
                src: values.file_obj,
                width: 150,
                height: 150
            });
        } else if (values.image) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                alt: "product image",
                src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_21__/* .productImageURL */ .k1)(values.image),
                width: 150,
                height: 150
            });
        }
    };
    const categoryModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
            open: modalOpen,
            keepMounted: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                    children: "กรุณาเลือกประเภทสินค้า"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.List, {
                        children: categories && categories.map((category)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItem, {
                                button: true,
                                onClick: ()=>handleSelectCategory(category),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                    primary: category.name
                                })
                            }, category.id))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleCloseModal,
                        children: "Cancel"
                    })
                })
            ]
        });
    };
    const colorSchemeModal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Dialog, {
            open: colorShemeModalOpen,
            keepMounted: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogTitle, {
                    children: "กรุณาเลือกโทนสี"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.List, {
                        children: colorschemes && colorschemes.map((colorscheme)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItem, {
                                button: true,
                                onClick: ()=>handleSelectColorScheme(colorscheme),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.ListItemText, {
                                        primary: colorscheme.nameTH,
                                        secondary: colorscheme.hex
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                        sx: {
                                            width: 50,
                                            height: 50,
                                            backgroundColor: colorscheme.hex,
                                            borderRadius: "50%",
                                            border: "1px solid black",
                                            marginLeft: 2
                                        }
                                    })
                                ]
                            }, colorscheme.id))
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.DialogActions, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                        onClick: handleCloseColorSchemeModal,
                        children: "Cancel"
                    })
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Formik, {
                initialValues: initialValues,
                validate: (values)=>{
                    let errors = {};
                    if (!values.name) errors.name = "กรุณากรอกชื่อสินค้า";
                    if (!values.desc) errors.desc = "กรุณากรอกรายละเอียดสินค้า";
                    if (!values.price) errors.price = "กรุณากรอกราคาสินค้า";
                    return errors;
                },
                onSubmit: (values, { setSubmitting  })=>{
                    handleUpdate(values); // call handleUpdate function for updating the product
                    setSubmitting(false);
                },
                children: ({ values , handleChange , handleBlur , isSubmitting , setFieldValue  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Form, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Card, {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardContent, {
                                    sx: {
                                        padding: 4
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                            gutterBottom: true,
                                            variant: "h3",
                                            children: "แก้ไขข้อมูลสินค้า"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "name",
                                            type: "text",
                                            label: "ชื่อสินค้า",
                                            value: values.name,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "desc",
                                            type: "string",
                                            label: "รายละเอียดสินค้า",
                                            value: values.desc,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.Field, {
                                            style: {
                                                marginTop: 16
                                            },
                                            fullWidth: true,
                                            as: _mui_material__WEBPACK_IMPORTED_MODULE_2__.TextField,
                                            name: "price",
                                            type: "number",
                                            label: "ราคาสินค้า",
                                            value: values.price,
                                            onChange: handleChange,
                                            onBlur: handleBlur
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenModal,
                                                children: selectedCategory && selectedCategory.name !== "" ? selectedCategory.name : "เลือกประเภทสินค้า"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                onClick: handleOpenColorSchemeModal,
                                                children: [
                                                    selectedColorScheme ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                        sx: {
                                                            width: 50,
                                                            height: 50,
                                                            backgroundColor: selectedColorScheme.hex,
                                                            borderRadius: "50%",
                                                            border: "1px solid black",
                                                            marginRight: 2
                                                        }
                                                    }) : null,
                                                    selectedColorScheme ? `${selectedColorScheme.nameTH} / ${selectedColorScheme.nameEN} / ${selectedColorScheme.hex}  ` : "เลือกโทนสี"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            style: {
                                                marginTop: 16
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "files",
                                                style: {
                                                    display: "flex",
                                                    alignItems: "center",
                                                    cursor: "pointer"
                                                },
                                                children: existingImages?.map((image)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            showPreviewImage({
                                                                image: image.image
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_18__.IconButton, {
                                                                onClick: ()=>handleDeleteExistImage(image),
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_14__.Delete, {})
                                                            })
                                                        ]
                                                    }, image.id))
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_1__.FieldArray, {
                                            name: "images",
                                            render: (arrayHelpers)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    style: {
                                                        marginTop: 16
                                                    },
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                                        container: true,
                                                        spacing: 2,
                                                        children: [
                                                            previewImages.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                                                    item: true,
                                                                    xs: 12,
                                                                    sm: 6,
                                                                    md: 4,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Paper, {
                                                                        elevation: 3,
                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                                            position: "relative",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                    src: image,
                                                                                    alt: "preview",
                                                                                    width: "100%"
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                                                    position: "absolute",
                                                                                    top: 0,
                                                                                    right: 0,
                                                                                    zIndex: "tooltip",
                                                                                    bgcolor: "rgba(0, 0, 0, 0.5)",
                                                                                    borderRadius: "0 0 0 5px",
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_18__.IconButton, {
                                                                                        onClick: ()=>handleDeleteImage(image),
                                                                                        color: "secondary",
                                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_14__.Delete, {})
                                                                                    })
                                                                                })
                                                                            ]
                                                                        })
                                                                    })
                                                                }, index)),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                                                item: true,
                                                                xs: 12,
                                                                sm: 6,
                                                                md: 4,
                                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                    htmlFor: "images",
                                                                    style: {
                                                                        cursor: "pointer"
                                                                    },
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                                            display: "flex",
                                                                            flexDirection: "column",
                                                                            justifyContent: "center",
                                                                            alignItems: "center",
                                                                            border: "1px dashed #00B0CD",
                                                                            borderRadius: "5px",
                                                                            minHeight: "250px",
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_14__.CloudUpload, {
                                                                                    style: {
                                                                                        marginRight: 10
                                                                                    }
                                                                                }),
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                                    style: {
                                                                                        color: "#00B0CD"
                                                                                    },
                                                                                    children: "เพิ่มรูปภาพ"
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                            id: "images",
                                                                            name: "images",
                                                                            type: "file",
                                                                            accept: "image/*",
                                                                            multiple: true,
                                                                            onChange: (event)=>{
                                                                                if (event.currentTarget.files) {
                                                                                    handleImageChange(event);
                                                                                }
                                                                            },
                                                                            style: {
                                                                                display: "none"
                                                                            }
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CardActions, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                            disabled: isSubmitting,
                                            fullWidth: true,
                                            variant: "contained",
                                            color: "primary",
                                            type: "submit",
                                            sx: {
                                                marginRight: 1
                                            },
                                            children: "แก้ไข"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/panel/user/manage-product",
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                                variant: "outlined",
                                                fullWidth: true,
                                                children: "ยกเลิก"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "hidden",
                                            name: "id",
                                            value: product && product?.id
                                        }),
                                        " "
                                    ]
                                })
                            ]
                        })
                    })
            }),
            categoryModal(),
            colorSchemeModal()
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(AddProductForm));
const getServerSideProps = async (context)=>{
    const { id  } = context.query;
    if (id) {
        const accessToken = context.req.cookies["access_token"];
        const { gid  } = await _services_auth_service__WEBPACK_IMPORTED_MODULE_13__/* .getSessionServerSide */ .jj(accessToken);
        const categories = await _services_category_service__WEBPACK_IMPORTED_MODULE_12__/* .getAllCategory */ .KQ();
        const product = await _services_product_service__WEBPACK_IMPORTED_MODULE_17__/* .getOneProduct */ .yO(id);
        const colorschemes = await _services_color_scheme_service__WEBPACK_IMPORTED_MODULE_15__/* .getAllColorScheme */ .iF();
        return {
            props: {
                product,
                accessToken,
                categories,
                gid,
                colorschemes
            }
        };
    } else {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3559:
/***/ (() => {



/***/ }),

/***/ 8130:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2105:
/***/ ((module) => {

"use strict";
module.exports = require("@material-ui/icons");

/***/ }),

/***/ 3694:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 8539:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 7934:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1431:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 271:
/***/ ((module) => {

"use strict";
module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

"use strict";
module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,2636,5675,7652,8227,4746,8105], () => (__webpack_exec__(7482)));
module.exports = __webpack_exports__;

})();