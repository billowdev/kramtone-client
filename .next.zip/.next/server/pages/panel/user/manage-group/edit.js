"use strict";
(() => {
var exports = {};
exports.id = 1361;
exports.ids = [1361,2894];
exports.modules = {

/***/ 348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4746);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8539);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8227);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8105);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6096);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6712);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(2554);
/* harmony import */ var _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4842);
/* harmony import */ var _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8117);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(6201);
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(6481);
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(9271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_8__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__, _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__, _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_20__, react_hot_toast__WEBPACK_IMPORTED_MODULE_21__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_8__, _components_withAuth__WEBPACK_IMPORTED_MODULE_10__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__, _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__, _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_20__, react_hot_toast__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















// import { TextField } from "formik-material-ui";






const MapContainer = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\edit.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const TileLayer = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\edit.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Marker = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\edit.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Popup = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\edit.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const validationSchema = (0,yup__WEBPACK_IMPORTED_MODULE_18__.object)().shape({
    groupName: (0,yup__WEBPACK_IMPORTED_MODULE_18__.string)().required("กรุณากรอกชื่อกลุ่มผู้ผลิต"),
    email: (0,yup__WEBPACK_IMPORTED_MODULE_18__.string)().email("Invalid email").required("กรุณากรอกอีเมล"),
    groupType: (0,yup__WEBPACK_IMPORTED_MODULE_18__.string)().required("กรุณาเลือกประเภทกลุ่ม")
});
const useStyles = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.makeStyles)((theme)=>({
        root: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            marginTop: theme.spacing(2),
            "& > *": {
                width: "50%",
                margin: theme.spacing(2)
            }
        },
        divider: {
            width: "50%",
            margin: theme.spacing(3),
            marginTop: "16px"
        },
        formLabel: {
            fontWeight: "bold"
        },
        radioGroup: {
            marginTop: theme.spacing(2)
        },
        input: {
            padding: theme.spacing(2),
            [theme.breakpoints.down("sm")]: {
                padding: 0
            }
        },
        uploadWrapper: {
            display: "flex",
            alignItems: "center",
            marginTop: theme.spacing(2),
            "& > *": {
                marginRight: theme.spacing(2)
            },
            [theme.breakpoints.down("sm")]: {
                flexDirection: "column",
                alignItems: "flex-start"
            }
        },
        inputLabel: {
            color: "#00B0CD",
            fontWeight: "bold",
            cursor: "pointer"
        },
        previewImage: {
            marginTop: theme.spacing(2)
        },
        errorMessage: {
            color: "red"
        }
    }));
const UserPanelEditGroup = ({ groupData , accessToken , provinces  })=>{
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const classes = useStyles();
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default()(theme.breakpoints.down("xs"));
    const isMediumDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default()(theme.breakpoints.down("md"));
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_8__/* .useAppDispatch */ .T)();
    const [currentLat, setCurrentLat] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(parseFloat(groupData?.lat));
    const [currentLng, setCurrentLng] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(parseFloat(groupData?.lng));
    const [currentLatLng, setCurrentLatLng] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([
        parseFloat(groupData?.lat),
        parseFloat(groupData?.lng)
    ]);
    const center = [
        currentLatLng[0],
        currentLatLng[1]
    ]; // Centered on Sakon Nakhon Province
    const position = [
        parseFloat(groupData?.lat ?? "17.1634"),
        parseFloat(groupData?.lng ?? "104.1476")
    ]; // Centered on Sakon Nakhon Province
    const zoom = 12;
    const [logoFile, setLogoFile] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [logoObj, setLogoObj] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [bannerFile, setBannerFile] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [bannerObj, setBannerObj] = react__WEBPACK_IMPORTED_MODULE_1___default().useState("");
    const [updateGroupData, setUpdateGroupData] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        id: groupData?.id,
        groupName: groupData?.groupName ?? "",
        groupType: groupData?.groupType ?? "shop",
        agency: groupData?.agency ?? "",
        logo: groupData?.logo ?? "",
        banner: groupData?.banner ?? "",
        phone: groupData?.phone ?? "",
        email: groupData?.email ?? "",
        hno: groupData?.hno ?? "",
        village: groupData?.village ?? "",
        lane: groupData?.lane ?? "",
        road: groupData?.road ?? "",
        subdistrict: groupData?.subdistrict ?? "",
        district: groupData?.district ?? "",
        province: groupData?.province ?? "",
        zipCode: groupData?.zipCode ?? "",
        lat: groupData?.lat ?? "",
        lng: groupData?.lng ?? ""
    });
    const [groupTypeState, setGroupTypeState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(groupData?.groupType ?? "shop");
    const [zipCodeState, setZipCodeState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(groupData?.zipCode ?? "");
    const [provinceState, setProvinceState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(groupData?.province ?? "");
    const [districtState, setDistrictState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(groupData?.district ?? "");
    const [subdistrictState, setSubdistrictState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(groupData?.subdistrict ?? "");
    const handleInputChange = (event, name)=>{
        const { value  } = event.target;
        setUpdateGroupData((prevState)=>({
                ...prevState,
                [name]: value
            }));
    };
    const handleMarkerDragEnd = (event)=>{
        setCurrentLat(event.target.getLatLng()["lat"]);
        setCurrentLng(event.target.getLatLng()["lng"]);
        setCurrentLatLng([
            parseFloat(event.target.getLatLng()["lat"]),
            parseFloat(event.target.getLatLng()["lng"])
        ]);
    };
    const [districts, setDistrict] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [subdistricts, setSubDistrict] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [selectedProvince, setSelectedProvince] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleProvinceChange = async (setFieldValue, event)=>{
        const selectedId = event.target.value;
        const selected = provinces?.find((p)=>p?.id === selectedId);
        const provinceName = selected?.nameTH;
        const provinceId = selected?.id;
        setProvinceState(provinceName);
        setSelectedProvince(selected);
        setFieldValue("province", provinceName);
        const districtData = await _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__/* .getDistricts */ .Wf(provinceId.toString());
        setDistrict(districtData);
    };
    const [selectedDistrict, setSelectedDistrict] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleDistrictChange = async (setFieldValue, event)=>{
        const selectedId = event.target.value;
        const selected = districts?.find((p)=>p?.id === selectedId);
        const districtName = selected?.nameTH;
        const districtId = selected?.id;
        setFieldValue("district", districtName);
        setDistrictState(districtName);
        setSelectedDistrict(selected);
        const subdistrictData = await _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__/* .getSubdistricts */ .sj(districtId.toString());
        setSubDistrict(subdistrictData);
    };
    const [openDialog, setOpenDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [selectedSubdistrict, setSelectedSubdistrict] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const handleSubdistrictChange = async (setFieldValue, event)=>{
        const selectedId = event.target.value;
        const selected = subdistricts?.find((p)=>p?.id === selectedId);
        const subdistrictName = selected?.nameTH;
        const subdistrictZipCode = selected?.zipCode;
        setFieldValue("subdistrict", subdistrictName);
        setSubdistrictState(subdistrictName);
        setSelectedSubdistrict(selected);
        setZipCodeState(subdistrictZipCode?.toString());
    };
    const showPreviewLogo = (values)=>{
        if (values.logoObj) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                alt: "group logo image",
                src: values.logoObj,
                width: 250,
                height: 250
            });
        } else if (values.logo) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full relative pt-[100%]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                    alt: "group logo image",
                    src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_25__/* .groupDataImageURL */ .vJ)(values.logo),
                    width: isSmallDevice ? 150 : 250,
                    height: isSmallDevice ? 150 : 250,
                    className: "w-full h-full top-0 left-0 object-cover rounded-2xl"
                })
            });
        }
    };
    const showPreviewBanner = (values)=>{
        if (values.bannerObj) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                alt: "group banner image",
                src: values.bannerObj,
                width: isSmallDevice ? 200 : 400,
                height: isSmallDevice ? 30 : 60
            });
        } else if (values.banner) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                alt: "group banner image",
                src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_25__/* .groupDataImageURL */ .vJ)(values.banner),
                width: isSmallDevice ? 200 : 400,
                height: isSmallDevice ? 30 : 60
            });
        }
    };
    const showDialog = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Dialog, {
            open: openDialog,
            keepMounted: true,
            "aria-labelledby": "alert-dialog-slide-title",
            "aria-describedby": "alert-dialog-slide-description",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.DialogTitle, {
                    id: "alert-dialog-slide-title",
                    children: "ยืนยันการแก้ไขข้อมูล"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.DialogContentText, {
                        id: "alert-dialog-slide-description",
                        children: "คุณต้องการแก้ไขข้อมูลใช่หรือไม่"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.DialogActions, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            onClick: handleEditConfirm,
                            color: "primary",
                            children: "ยืนยัน"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            onClick: ()=>setOpenDialog(false),
                            color: "info",
                            children: "ยกเลิก"
                        })
                    ]
                })
            ]
        });
    };
    const handleEditConfirm = async ()=>{
        let formData = new FormData();
        if (logoFile != "") {
            formData.append("logoFile", logoFile);
        }
        if (bannerFile != "") {
            formData.append("bannerFile", bannerFile);
        }
        formData.append("groupData", JSON.stringify({
            "groupName": updateGroupData.groupName,
            "groupType": groupTypeState,
            "agency": updateGroupData.agency,
            "phone": updateGroupData.phone,
            "email": updateGroupData.email,
            "hno": updateGroupData.hno,
            "village": updateGroupData.village,
            "lane": updateGroupData.lane,
            "road": updateGroupData.road,
            "subdistrict": updateGroupData.subdistrict,
            "district": updateGroupData.district,
            "province": updateGroupData.province,
            "zipCode": zipCodeState,
            "lat": currentLat,
            "lng": currentLng
        }));
        const updateStatus = await dispatch((0,_store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_20__/* .updateGroupDataAction */ .U2)({
            id: updateGroupData.id,
            body: formData,
            accessToken
        }));
        if (updateStatus.meta.requestStatus === "fulfilled") {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].success("แก้ไขข้อมูลสำเร็จ");
            next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/panel/user/manage-group");
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].error("แก้ไขข้อมูลไม่สำเร็จ โปรดลองอีกครั้ง");
        }
        setOpenDialog(false);
    // }
    };
    const showForm = ({ values , isValid , setFieldValue  })=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(formik__WEBPACK_IMPORTED_MODULE_9__.Form, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                    container: true,
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                            item: true,
                            xs: 12,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                    style: {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        flexDirection: "column",
                                        marginTop: 3
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Divider, {
                                            style: {
                                                width: "50%",
                                                margin: 8
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                                            variant: "h5",
                                            children: "ข้อมูลกลุ่ม"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Divider, {
                                            style: {
                                                width: "50%",
                                                margin: 8
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                    container: true,
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 12,
                                            lg: 6,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    htmlFor: "logo",
                                                    style: {
                                                        fontWeight: "bold"
                                                    },
                                                    children: "ภาพโลโก้ ขนาด 250 x 250 px"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    style: {
                                                        padding: isSmallDevice ? 0 : 4
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: showPreviewLogo(values)
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                                    alt: "product image",
                                                                    src: "/static/img/default.png",
                                                                    width: 25,
                                                                    height: 20
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "#00B0CD",
                                                                        marginLeft: 10
                                                                    },
                                                                    children: "เปลี่ยนภาพโลโก้"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "file",
                                                                    onChange: (e)=>{
                                                                        e.preventDefault();
                                                                        setFieldValue("logoFile", e.target.files[0]); // for upload
                                                                        // setLogoFile(e.target.files[0])
                                                                        // setLogoObj(URL.createObjectURL(e.target.files[0]))
                                                                        setFieldValue("logoObj", URL.createObjectURL(e.target.files[0])); // for preview image
                                                                    },
                                                                    name: "logo",
                                                                    "click-type": "type1",
                                                                    multiple: true,
                                                                    accept: "image/*",
                                                                    id: "logo",
                                                                    style: {
                                                                        padding: "20px 0 0 20px"
                                                                    }
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    htmlFor: "banner",
                                                    style: {
                                                        fontWeight: "bold"
                                                    },
                                                    children: "ภาพแบนเนอร์ ขนาด 1200 x 160 px"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    style: {
                                                        padding: isSmallDevice ? 0 : 4
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: showPreviewBanner(values)
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                                    alt: "product image",
                                                                    src: "/static/img/default.png",
                                                                    width: 25,
                                                                    height: 20
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "#00B0CD",
                                                                        marginLeft: 10
                                                                    },
                                                                    children: "เปลี่ยนภาพแบนเนอร์"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                    type: "file",
                                                                    onChange: (e)=>{
                                                                        e.preventDefault();
                                                                        // setBannerFile(e.target.files[0])
                                                                        // setBannerObj(URL.createObjectURL(e.target.files[0]))
                                                                        setFieldValue("bannerFile", e.target.files[0]); // for upload
                                                                        setFieldValue("bannerObj", URL.createObjectURL(e.target.files[0])); // for preview image
                                                                    },
                                                                    name: "banner",
                                                                    "click-type": "type1",
                                                                    multiple: true,
                                                                    accept: "image/*",
                                                                    id: "banner",
                                                                    style: {
                                                                        padding: "20px 0 0 20px"
                                                                    }
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            sm: 12,
                                            md: 6,
                                            lg: 6,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    style: {
                                                        marginTop: 3
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "email",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "ชื่อกลุ่มผู้ผลิตหรือร้านค้า",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                            name: "groupName",
                                                            inputProps: {
                                                                maxLength: 100
                                                            },
                                                            fullWidth: true,
                                                            type: "text",
                                                            defaultValue: updateGroupData.groupName,
                                                            onChange: (e)=>{
                                                                handleInputChange(e, "groupName");
                                                            },
                                                            label: "ชื่อกลุ่มผู้ผลิตหรือร้านค้า",
                                                            component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                            style: {
                                                                marginTop: 3
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "groupName"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    sx: {
                                                        marginTop: 3
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "groupType",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "ประเภทกลุ่ม ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                            row: true,
                                                            value: groupTypeState,
                                                            onChange: (event)=>{
                                                                setGroupTypeState(event.target.value);
                                                            },
                                                            "aria-labelledby": "group-type-row-radio-buttons-group-label",
                                                            name: "groupType",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.FormControlLabel, {
                                                                    value: "shop",
                                                                    control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_12___default()), {}),
                                                                    label: "ร้านค้า"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.FormControlLabel, {
                                                                    value: "producer",
                                                                    control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_12___default()), {}),
                                                                    label: "กลุ่มผู้ผลิต"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "groupType"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    sx: {
                                                        marginTop: 3
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "agency",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "ชื่อประธาน / เจ้าของร้าน",
                                                                " ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                            name: "agency",
                                                            type: "text",
                                                            inputProps: {
                                                                maxLength: 160
                                                            },
                                                            defaultValue: groupData?.agency,
                                                            fullWidth: true,
                                                            label: "ชื่อประธาน / เจ้าของร้าน",
                                                            component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                            onChange: (e)=>{
                                                                handleInputChange(e, "agency");
                                                            },
                                                            sx: {
                                                                marginTop: 3
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "agency"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    sx: {
                                                        marginTop: 3
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "phone",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "เบอร์โทร ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                            name: "phone",
                                                            type: "text",
                                                            inputProps: {
                                                                maxLength: 10
                                                            },
                                                            defaultValue: groupData?.phone,
                                                            onChange: (e)=>{
                                                                handleInputChange(e, "phone");
                                                            },
                                                            fullWidth: true,
                                                            label: "เบอร์โทร",
                                                            component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                            sx: {
                                                                marginTop: 3
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "phone"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                    sx: {
                                                        marginTop: 3
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "email",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "อีเมล ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                            name: "email",
                                                            type: "email",
                                                            inputProps: {
                                                                maxLength: 120
                                                            },
                                                            defaultValue: groupData?.email,
                                                            onChange: (e)=>{
                                                                handleInputChange(e, "email");
                                                            },
                                                            fullWidth: true,
                                                            label: "อีเมล",
                                                            component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                            sx: {
                                                                marginTop: 3
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "email"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                            item: true,
                            xs: 12,
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                    style: {
                                        display: "flex",
                                        justifyContent: "center",
                                        alignItems: "center",
                                        flexDirection: "column",
                                        marginTop: 3
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Divider, {
                                            style: {
                                                width: "50%",
                                                margin: 8
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                                            variant: "h5",
                                            children: "ข้อมูลที่อยู่"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Divider, {
                                            style: {
                                                width: "50%",
                                                margin: 8
                                            }
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                    container: true,
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.FormControl, {
                                                    fullWidth: true,
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "province",
                                                            sx: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "จังหวัด ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.Select, {
                                                            id: "province",
                                                            className: "selectProvince",
                                                            labelId: "province-label",
                                                            displayEmpty: true,
                                                            value: selectedProvince?.id || "",
                                                            onChange: (e)=>handleProvinceChange(setFieldValue, e),
                                                            style: {
                                                                marginTop: "16px"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                    value: "",
                                                                    children: provinceState || "-- โปรดเลือกจังหวัด --"
                                                                }),
                                                                provinces && provinces.map((province)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                        value: province.id,
                                                                        children: province.nameTH
                                                                    }, province.id))
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "province"
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.FormControl, {
                                                    fullWidth: true,
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "province",
                                                            style: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "อำเภอ ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.Select, {
                                                            id: "district",
                                                            className: "selectDistrict",
                                                            labelId: "district-label",
                                                            displayEmpty: true,
                                                            value: selectedDistrict?.id || "",
                                                            onChange: (e)=>handleDistrictChange(setFieldValue, e),
                                                            style: {
                                                                marginTop: "16px"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                    value: "",
                                                                    children: districtState || "-- โปรดเลือกอำเภอ --"
                                                                }),
                                                                provinces && districts && districts.map((district)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                        value: district.id,
                                                                        children: district.nameTH
                                                                    }, district.id))
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "district"
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.FormControl, {
                                                    fullWidth: true,
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                            htmlFor: "subdistrict",
                                                            sx: {
                                                                fontWeight: "bold"
                                                            },
                                                            children: [
                                                                "ตำบล ",
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    style: {
                                                                        color: "red"
                                                                    },
                                                                    children: "*"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_23__.Select, {
                                                            id: "subdistrict",
                                                            className: "selectSubdistrict",
                                                            labelId: "subdistrict-label",
                                                            displayEmpty: true,
                                                            value: selectedSubdistrict?.id || "",
                                                            onChange: (e)=>handleSubdistrictChange(setFieldValue, e),
                                                            style: {
                                                                marginTop: "16px"
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                    value: "",
                                                                    children: subdistrictState || "-- โปรดเลือกตำบล --"
                                                                }),
                                                                provinces && districts && subdistricts && subdistricts.map((subdistrict)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_24___default()), {
                                                                        value: subdistrict.id,
                                                                        children: subdistrict.nameTH
                                                                    }, subdistrict.id))
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                            name: "subdistrict"
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        htmlFor: "zipCode",
                                                        style: {
                                                            fontWeight: "bold"
                                                        },
                                                        children: [
                                                            "รหัสไปรษณีย์ ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                style: {
                                                                    color: "red"
                                                                },
                                                                children: "*"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                        name: "zipCode",
                                                        type: "text",
                                                        fullWidth: true,
                                                        value: zipCodeState,
                                                        onChange: (e)=>{
                                                            setZipCodeState(e.target.value);
                                                        },
                                                        label: "รหัสไปรษณีย์",
                                                        inputProps: {
                                                            maxLength: 10
                                                        },
                                                        component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                        sx: {
                                                            marginTop: 3
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                        name: "zipCode"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        htmlFor: "hno",
                                                        style: {
                                                            fontWeight: "bold"
                                                        },
                                                        children: [
                                                            "บ้านเลขที่/หมู่ ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                style: {
                                                                    color: "red"
                                                                },
                                                                children: "*"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                        name: "hno",
                                                        type: "text",
                                                        fullWidth: true,
                                                        inputProps: {
                                                            maxLength: 5
                                                        },
                                                        defaultValue: updateGroupData?.hno,
                                                        onChange: (e)=>{
                                                            handleInputChange(e, "hno");
                                                        },
                                                        label: "บ้านเลขที่/หมู่",
                                                        component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                        sx: {
                                                            marginTop: 3
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                        name: "hno"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        htmlFor: "lane",
                                                        style: {
                                                            fontWeight: "bold"
                                                        },
                                                        children: "ซอย"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                        name: "lane",
                                                        type: "text",
                                                        fullWidth: true,
                                                        defaultValue: updateGroupData?.lane,
                                                        onChange: (e)=>{
                                                            handleInputChange(e, "lane");
                                                        },
                                                        inputProps: {
                                                            maxLength: 50
                                                        },
                                                        label: "ซอย",
                                                        component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                        sx: {
                                                            marginTop: 3
                                                        }
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        htmlFor: "road",
                                                        style: {
                                                            fontWeight: "bold"
                                                        },
                                                        children: "ถนน"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                        name: "road",
                                                        type: "text",
                                                        defaultValue: updateGroupData?.road,
                                                        onChange: (e)=>{
                                                            handleInputChange(e, "road");
                                                        },
                                                        inputProps: {
                                                            maxLength: 50
                                                        },
                                                        fullWidth: true,
                                                        label: "ถนน",
                                                        component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                        sx: {
                                                            marginTop: 3
                                                        }
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 6,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                                sx: {
                                                    marginTop: 3
                                                },
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        htmlFor: "village",
                                                        sx: {
                                                            fontWeight: "bold"
                                                        },
                                                        children: [
                                                            "หมู่บ้าน ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                style: {
                                                                    color: "red"
                                                                },
                                                                children: "*"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Field, {
                                                        name: "village",
                                                        defaultValue: updateGroupData?.village,
                                                        onChange: (e)=>{
                                                            handleInputChange(e, "village");
                                                        },
                                                        type: "text",
                                                        fullWidth: true,
                                                        label: "หมู่บ้าน",
                                                        component: (_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_22___default()),
                                                        sx: {
                                                            marginTop: 3
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.ErrorMessage, {
                                                        name: "village"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.CardActions, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                            type: "submit",
                            variant: "contained",
                            fullWidth: true,
                            disabled: !isValid,
                            sx: {
                                marginRight: 1
                            },
                            children: isSmallDevice ? "บันทึก" : "บันทึกข้อมูล"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                            href: "/panel/user/manage-group",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                variant: "outlined",
                                fullWidth: true,
                                children: "ยกเลิก"
                            })
                        })
                    ]
                })
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Container, {
                maxWidth: "lg",
                sx: {
                    marginTop: 4,
                    marginBottom: 4
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                        container: true,
                        spacing: 3,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                            item: true,
                            xs: 12,
                            sm: 12,
                            md: 12,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Paper, {
                                sx: {
                                    padding: 1,
                                    display: "flex",
                                    flexDirection: "row",
                                    gap: 16
                                },
                                children: [
                                    isSmallDevice ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        sx: {
                                            fontSize: "1.5rem",
                                            marginLeft: "8px"
                                        }
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        sx: {
                                            fontSize: "2.5rem",
                                            marginLeft: "16px"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                        children: isSmallDevice ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                                            sx: {
                                                fontWeight: "bold",
                                                alignSelf: "center"
                                            },
                                            children: [
                                                " ",
                                                "หน้าแก้ไขข้อมูลกลุ่ม ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                " / ร้านค้า",
                                                " "
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Typography, {
                                            variant: "h5",
                                            sx: {
                                                fontWeight: "bold",
                                                alignSelf: "center"
                                            },
                                            children: [
                                                " ",
                                                "หน้าแก้ไขข้อมูลกลุ่ม / ร้านค้า"
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                        container: true,
                        spacing: 2,
                        sx: {
                            marginTop: 3
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Paper, {
                                    sx: {
                                        p: 6,
                                        display: "flex",
                                        gap: "4rem",
                                        flexDirection: {
                                            xs: "column",
                                            md: "row"
                                        }
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                        item: true,
                                        xs: 12,
                                        md: 12,
                                        lg: 12,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Box, {
                                            sx: {
                                                padding: 4
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_9__.Formik, {
                                                initialValues: groupData,
                                                validationSchema: validationSchema,
                                                onSubmit: async (values, { setSubmitting  })=>{
                                                    setLogoFile(values.logoFile);
                                                    setBannerFile(values.bannerFile);
                                                    setOpenDialog(true);
                                                    setSubmitting(false);
                                                },
                                                children: (props)=>showForm(props)
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                                item: true,
                                xs: 12,
                                md: 12,
                                lg: 12,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Paper, {
                                    sx: {
                                        p: 2,
                                        display: "flex",
                                        flexDirection: "column",
                                        gap: 16
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MapContainer, {
                                        center: center,
                                        zoom: zoom,
                                        style: {
                                            height: "500px",
                                            width: "100%"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TileLayer, {
                                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Marker, {
                                                position: center,
                                                draggable: true,
                                                eventHandlers: {
                                                    dragend: handleMarkerDragEnd
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Popup, {
                                                    autoClose: false,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "หมุดของคุณ"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            showDialog()
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(UserPanelEditGroup));
const getServerSideProps = async (context)=>{
    const { gid  } = context.query;
    if (gid) {
        const groupData = await _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__/* .getOneGroupData */ .BS(gid);
        const accessToken = context.req.cookies["access_token"];
        const provinces = await _services_thai_address_service__WEBPACK_IMPORTED_MODULE_19__/* .getProvinces */ .uy();
        return {
            props: {
                groupData,
                accessToken,
                provinces
            }
        };
    } else {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wf": () => (/* binding */ getDistricts),
/* harmony export */   "sj": () => (/* binding */ getSubdistricts),
/* harmony export */   "uy": () => (/* binding */ getProvinces)
/* harmony export */ });
/* unused harmony exports getGrographies, getProvinceByGrography, getDistrictById, getSubdistrictsByZipCode */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getGrographies = async ()=>{
    const { data: response  } = await axios.get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/geographies.json`);
    const { payload  } = response;
    return payload;
};
const getProvinceByGrography = async (geographyId)=>{
    const { data: response  } = await axios.get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/provinces.json`);
    const { payload  } = response;
    const filteredPayload = payload.filter((item)=>item.geographyId === parseInt(geographyId));
    return filteredPayload;
};
const getProvinces = async ()=>{
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/provinces.json`);
    const { payload  } = response;
    return payload;
};
const getDistricts = async (provinceId)=>{
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/districts.json`);
    const { payload  } = response;
    const filteredPayload = payload.filter((item)=>item.provinceId === parseInt(provinceId));
    return filteredPayload;
};
const getDistrictById = async (districtId)=>{
    const { data: response  } = await axios.get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/districts.json`);
    const { payload  } = response;
    const filteredPayload = payload.filter((item)=>item.id === parseInt(districtId));
    return filteredPayload;
};
const getSubdistricts = async (districtId)=>{
    const { data: response  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/subdistricts.json`);
    const { payload  } = response;
    const filteredPayload = payload.filter((item)=>item.districtId === parseInt(districtId));
    return filteredPayload;
};
const getSubdistrictsByZipCode = async (zipcode)=>{
    const { data: response  } = await axios.get(`${"https://raw.githubusercontent.com/billowdev/json/main/thai-address-camel-case"}/subdistricts.json`);
    const { payload  } = response;
    const filteredPayload = payload.filter((item)=>item.zipCode === parseInt(zipcode));
    return filteredPayload;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 6481:
/***/ ((module) => {

module.exports = require("@material-ui/core/TextField");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2812:
/***/ ((module) => {

module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ 3694:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 8539:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 9271:
/***/ ((module) => {

module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 5374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 6563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,2636,5675,5152,7652,8227,4746,8105], () => (__webpack_exec__(348)));
module.exports = __webpack_exports__;

})();