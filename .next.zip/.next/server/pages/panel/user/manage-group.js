"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,2894];
exports.modules = {

/***/ 7017:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4746);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8539);
/* harmony import */ var _mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2812);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8227);
/* harmony import */ var _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8117);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7652);
/* harmony import */ var _components_withAuth__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8105);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6096);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _common_utils_utils__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2554);
/* harmony import */ var _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6712);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1809);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_7__, _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_8__, _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_11__, _components_withAuth__WEBPACK_IMPORTED_MODULE_12__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__, _services_auth_service__WEBPACK_IMPORTED_MODULE_18__]);
([_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__, _store_store__WEBPACK_IMPORTED_MODULE_7__, _store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_8__, _store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_11__, _components_withAuth__WEBPACK_IMPORTED_MODULE_12__, _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__, _services_auth_service__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const MapContainer = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const TileLayer = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Marker = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Popup = next_dynamic__WEBPACK_IMPORTED_MODULE_16___default()(null, {
    loadableGenerated: {
        modules: [
            "panel\\user\\manage-group\\index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
function UserPanelManageGroup({ groupDataProp  }) {
    const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_6__.useTheme)();
    const isSmallDevice = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_5___default()(theme.breakpoints.down("xs"));
    const dispatch = (0,_store_store__WEBPACK_IMPORTED_MODULE_7__/* .useAppDispatch */ .T)();
    const { groupData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)(_store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_8__/* .groupDataSelector */ .S5);
    const userData = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)(_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_11__/* .authSelector */ .aF);
    const isLoading = userData === undefined;
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        dispatch((0,_store_slices_auth_slice__WEBPACK_IMPORTED_MODULE_11__/* .fetchSession */ .BT)());
    }, [
        dispatch
    ]);
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        //  async function fethData() {
        //   const data = await  dispatch(getAllGroupDataAction());
        //   console.log("====== async effect")
        //   console.log(data.payload)
        //  }
        //  if(userData){
        //    fethData()
        //  }
        if (userData) {
            dispatch((0,_store_slices_group_data_slice__WEBPACK_IMPORTED_MODULE_8__/* .getOneGroupDataAction */ .Pu)(userData.gid));
        }
    }, [
        dispatch,
        userData
    ]);
    const center = [
        17.1634,
        104.1476
    ]; // Centered on Sakon Nakhon Province
    const position = [
        parseFloat(groupDataProp?.lat),
        parseFloat(groupDataProp?.lng)
    ]; // Centered on Sakon Nakhon Province
    const zoom = 12;
    const initialValues = {
        groupName: groupData?.groupName,
        groupType: groupData?.groupType,
        agency: groupData?.agency,
        logo: groupData?.logo,
        banner: groupData?.banner,
        phone: groupData?.phone,
        email: groupData?.email,
        hno: groupData?.hno,
        village: groupData?.village,
        lane: groupData?.lane,
        road: groupData?.road,
        subdistrict: groupData?.subdistrict,
        district: groupData?.district,
        province: groupData?.province,
        zipCode: groupData?.zipCode,
        lat: groupData?.lat,
        lng: groupData?.lng
    };
    const typeographyHeaderStyle = {
        fontSize: isSmallDevice ? "16px" : "1.2rem",
        alignSelf: "flex-start",
        fontWeight: "bold",
        width: "100%",
        color: theme.palette.grey[800]
    };
    const typeographyValueStyle = {
        fontSize: isSmallDevice ? "16px" : "1.2rem",
        alignSelf: "flex-start",
        width: "100%",
        color: theme.palette.grey[800]
    };
    const boxStyle = {
        display: "flex",
        marginTop: "16px"
    };
    const showForm = ({ isValid  })=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_10__.Form, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Card, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CardContent, {
                        sx: {
                            padding: 4
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                htmlFor: "groupName",
                                sx: {
                                    marginTop: "16px"
                                },
                                children: "ชื่อกลุ่มผู้ผลิตหรือร้านค้า"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_10__.Field, {
                                style: {
                                    marginTop: 16
                                },
                                fullWidth: true,
                                value: groupData.groupName,
                                component: _mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField,
                                name: "groupName",
                                type: "text",
                                label: "ชื่อกลุ่มผู้ผลิตหรือร้านค้า"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                sx: {
                                    marginTop: "16px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_14___default()), {
                                        htmlFor: "groupName",
                                        children: "ชื่อกลุ่มผู้ผลิตหรือร้านค้า"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_10__.Field, {
                                        style: {
                                            marginTop: 16
                                        },
                                        fullWidth: true,
                                        value: groupData.groupName,
                                        component: _mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField,
                                        name: "groupName",
                                        type: "text",
                                        label: "ชื่อกลุ่มผู้ผลิตหรือร้านค้า"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.CardActions, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                disabled: !isValid,
                                fullWidth: true,
                                variant: "contained",
                                color: "primary",
                                type: "submit",
                                sx: {
                                    marginRight: 1
                                },
                                children: "แก้ไข"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                variant: "outlined",
                                fullWidth: true,
                                onClick: ()=>setOpenDialog(false),
                                children: "ยกเลิก"
                            })
                        ]
                    })
                ]
            })
        });
    };
    const [openDialog, setOpenDialog] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const showDialog = ()=>{
        if (groupData === null) {
            return;
        }
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Dialog, {
            open: openDialog,
            keepMounted: true,
            "aria-labelledby": "alert-dialog-slide-title",
            "aria-describedby": "alert-dialog-slide-description",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogTitle, {
                    id: "alert-dialog-slide-title",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                            gutterBottom: true,
                            children: "แก้ไขข้อมูลกลุ่มผู้ผลิตหรือร้านค้า"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Divider, {})
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.DialogContent, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_10__.Formik, {
                        validate: (values)=>{
                            let errors = {};
                            return errors;
                        },
                        initialValues: initialValues,
                        onSubmit: async (values, { setSubmitting  })=>{
                            setSubmitting(false);
                        },
                        children: (props)=>showForm(props)
                    })
                })
            ]
        });
    };
    const handleOnEditClick = ()=>{
    // router.push('/panel/user/manage-group/edit?gid=' + userData.gid)
    // const editUrl = '/panel/user/manage-group/edit?gid=' + userData.gid;
    // return (
    //   <Link href={editUrl}>
    //     <a>Edit Group</a>
    //   </Link>
    // );
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layouts_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {
                maxWidth: "lg",
                sx: {
                    mt: 4,
                    mb: 4
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        container: true,
                        spacing: 3,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                            item: true,
                            xs: 12,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                                sx: {
                                    p: 2,
                                    display: "flex",
                                    flexDirection: "row",
                                    gap: "16px"
                                },
                                children: [
                                    isSmallDevice ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        sx: {
                                            fontSize: "1.5rem",
                                            marginLeft: "8px"
                                        }
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Groups__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        sx: {
                                            fontSize: "2.5rem",
                                            marginLeft: "16px"
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                        children: isSmallDevice ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                            sx: {
                                                fontWeight: "bold",
                                                alignSelf: "center"
                                            },
                                            children: [
                                                " ",
                                                "หน้าจัดการข้อมูลกลุ่ม ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                " / ร้านค้า",
                                                " "
                                            ]
                                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                            variant: "h5",
                                            sx: {
                                                fontWeight: "bold",
                                                alignSelf: "center"
                                            },
                                            children: [
                                                " ",
                                                "หน้าจัดการข้อมูลกลุ่ม / ร้านค้า"
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        container: true,
                        spacing: 2,
                        style: {
                            marginTop: "16px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                md: 12,
                                lg: 12,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                                    sx: {
                                        p: 2,
                                        display: "flex",
                                        gap: "4rem",
                                        flexDirection: {
                                            xs: "column",
                                            md: "row"
                                        },
                                        overflow: "hidden"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        alt: "product image",
                                        src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_19__/* .groupDataImageURL */ .vJ)(groupData.banner),
                                        width: 1120,
                                        height: 160
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                                    sx: {
                                        p: 2,
                                        display: "flex",
                                        gap: "4rem",
                                        flexDirection: {
                                            xs: "column",
                                            md: "row"
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 4,
                                            lg: 3,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                style: {
                                                    objectFit: "cover"
                                                },
                                                alt: "product image",
                                                src: (0,_common_utils_utils__WEBPACK_IMPORTED_MODULE_19__/* .groupDataImageURL */ .vJ)(groupData.logo),
                                                width: 250,
                                                height: 250
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            md: 8,
                                            lg: 9,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                        sx: boxStyle,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyHeaderStyle,
                                                                children: "ชื่อกลุ่ม / ร้านค้า"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyValueStyle,
                                                                children: groupData.groupName
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                        sx: boxStyle,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyHeaderStyle,
                                                                children: "ประเภทกลุ่ม"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyValueStyle,
                                                                children: groupData.groupType === "shop" ? "ร้านค้า" : "กลุ่มผู้ผลิต"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                        sx: boxStyle,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyHeaderStyle,
                                                                children: "ชื่อประธาน / เจ้าของร้าน"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyValueStyle,
                                                                children: groupData.agency
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                        sx: boxStyle,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyHeaderStyle,
                                                                children: "เบอร์โทร"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyValueStyle,
                                                                children: groupData.phone
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                        sx: boxStyle,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyHeaderStyle,
                                                                children: "อีเมล :"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                                sx: typeographyValueStyle,
                                                                children: groupData.email
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                md: 12,
                                lg: 12,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                                    sx: {
                                        p: 2,
                                        display: "flex",
                                        flexDirection: "column",
                                        gap: "16px"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                        container: true,
                                        spacing: 2,
                                        sx: {
                                            alignSelf: "flex-center",
                                            paddingBottom: "16px",
                                            paddingLeft: "16px"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "บ้านเลขที่/หมู่"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.hno
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "ถนน :"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.road
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "ซอย :"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.lane
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "หมู่บ้าน"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.village
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "ตำบล"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.subdistrict
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "อำเภอ"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.district
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "จังหวัด"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.province
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 12,
                                                md: 6,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                                    sx: boxStyle,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyHeaderStyle,
                                                            children: "รหัสไปรษณีย์"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                            sx: typeographyValueStyle,
                                                            children: groupData.zipCode
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Container, {
                                maxWidth: "lg",
                                sx: {
                                    mt: 3,
                                    display: "flex",
                                    justifyContent: "flex-end"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_13___default()), {
                                    href: "/panel/user/manage-group/edit?gid=" + userData.gid,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                        color: "primary",
                                        variant: "contained",
                                        style: {
                                            margin: "8px 0",
                                            backgroundColor: theme.palette.primary.main,
                                            color: "#fff",
                                            fontWeight: "bold",
                                            boxShadow: `0px 5px 10px rgba(0, 0, 0, 0.3)`
                                        },
                                        onClick: ()=>{
                                            handleOnEditClick();
                                        // setOpenDialog(true);
                                        },
                                        children: "แก้ไขข้อมูล"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                md: 12,
                                lg: 12,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                                    sx: {
                                        p: 2,
                                        display: "flex",
                                        flexDirection: "column",
                                        gap: "16px"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MapContainer, {
                                        center: center,
                                        zoom: zoom,
                                        style: {
                                            height: "500px",
                                            width: "100%"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TileLayer, {
                                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Marker, {
                                                position: position,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Popup, {
                                                    autoClose: false,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "หมุดของคุณ"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            showDialog()
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_components_withAuth__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)(UserPanelManageGroup));
const getServerSideProps = async (context)=>{
    try {
        const accessToken = context.req.cookies["access_token"];
        const { gid  } = await _services_auth_service__WEBPACK_IMPORTED_MODULE_18__/* .getSessionServerSide */ .jj(accessToken);
        const groupDataProp = await _services_group_data_service__WEBPACK_IMPORTED_MODULE_17__/* .getOneGroupData */ .BS(gid);
        return {
            props: {
                groupDataProp
            }
        };
    } catch (error) {
        return {
            props: {}
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 8308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 2812:
/***/ ((module) => {

module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ 3694:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Checkroom");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 8507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ColorLens");

/***/ }),

/***/ 8539:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Groups");

/***/ }),

/***/ 3467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 8792:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Info");

/***/ }),

/***/ 9801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 3365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 6983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 5301:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Widgets");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 3882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 9048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 4960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 3646:
/***/ ((module) => {

module.exports = require("@mui/material/Divider");

/***/ }),

/***/ 7898:
/***/ ((module) => {

module.exports = require("@mui/material/Drawer");

/***/ }),

/***/ 6096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 7934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 4192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 3787:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemIcon");

/***/ }),

/***/ 8315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 1431:
/***/ ((module) => {

module.exports = require("@mui/material/Toolbar");

/***/ }),

/***/ 7163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [373,1664,2636,5675,5152,7652,8227,4746,8105], () => (__webpack_exec__(7017)));
module.exports = __webpack_exports__;

})();