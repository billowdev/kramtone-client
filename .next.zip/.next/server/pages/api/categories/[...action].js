"use strict";
(() => {
var exports = {};
exports.id = 8813;
exports.ids = [8813];
exports.modules = {

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$h": () => (/* binding */ HTTP_METHOD_GET),
/* harmony export */   "CK": () => (/* binding */ HTTP_METHOD_POST),
/* harmony export */   "L": () => (/* binding */ HTTP_METHOD_DELETE),
/* harmony export */   "Wx": () => (/* binding */ ACCESS_TOKEN_KEY),
/* harmony export */   "Z": () => (/* binding */ HTTP_METHOD_PATCH)
/* harmony export */ });
/* unused harmony exports API_REQUEST_SUCCESS, API_REQUEST_FAIL */
const ACCESS_TOKEN_KEY = "access_token";
const HTTP_METHOD_GET = "GET";
const HTTP_METHOD_POST = "POST";
const API_REQUEST_SUCCESS = "success";
const API_REQUEST_FAIL = "fail";
const HTTP_METHOD_DELETE = "DELETE";
const HTTP_METHOD_PATCH = "PATCH";


/***/ }),

/***/ 4568:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://www.kramtone.com/service/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6206:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4568);
/* harmony import */ var _constants_api_constant__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__]);
_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function handler(req, res) {
    if (req.query.action) {
        const requestAction = req.query["action"][0];
        if (req.method === _constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .HTTP_METHOD_GET */ .$h && requestAction == "getAllByGroup") {
            return getAllCategoryByGroup(req, res);
        } else if (req.method === _constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .HTTP_METHOD_DELETE */ .L) {
            return deleteCategory(req, res);
        } else if (req.method === _constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .HTTP_METHOD_PATCH */ .Z) {
            return updateCategory(req, res);
        } else {
            return res.status(405).end(`Error: HTTP ${req.method} is not supported for ${req.url}`);
        }
    }
}
async function getAllCategoryByGroup(req, res) {
    const accessToken = req.cookies[_constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .ACCESS_TOKEN_KEY */ .Wx];
    if (!accessToken) {
        return res.status(401).json({
            message: "Unauthorized"
        });
    }
    // console.log(req)
    if (req.query) {
        const { data  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/categories/group`, {
            headers: {
                "Authorization": `Bearer ${accessToken}`
            }
        });
        if (data) {
            return res.status(200).json(data);
        } else {
            return res.status(400).json(data);
        }
    } else {
        return res.status;
    }
}
async function deleteCategory(req, res) {
    try {
        const accessToken = req.cookies[_constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (!accessToken) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        if (req.query) {
            const { data  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/categorys/delete/${req.query["id"]}`, {
                headers: {
                    "Authorization": `Bearer ${accessToken}`
                }
            });
            if (data) {
                return res.status(200).json(data);
            } else {
                return res.status(400).json(data);
            }
        } else {
            return res.status(400).json({
                message: "id required"
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal Server Error"
        });
    }
}
async function updateCategory(req, res) {
    try {
        const accessToken = req.cookies[_constants_api_constant__WEBPACK_IMPORTED_MODULE_1__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (!accessToken) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        const updateBody = req.body;
        if (req.query) {
            const { data  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].patch */ .Z.patch(`/categorys/update/${req.query["id"]}`, updateBody, {
                headers: {
                    "Authorization": `Bearer ${accessToken}`
                }
            });
            if (data) {
                return res.status(200).json(data);
            } else {
                return res.status(400).json(data);
            }
        } else {
            return res.status(400).json({
                message: "id required"
            });
        }
    } catch (error) {
        // console.error(error);
        return res.status(500).json({
            message: "Internal Server Error"
        });
    }
} // async function createCategory(req: NextApiRequest, res: NextApiResponse<any>) {
 //   try {
 //     const accessToken = req.cookies[ACCESS_TOKEN_KEY];
 //     if (!accessToken) {
 //       return res.status(401).json({ message: 'Unauthorized' });
 //     }
 //     const createBody = req.body;
 // 	console.log(createBody)
 //     if (createBody) {
 //       const { data } = await httpClient.post(`/categories`, createBody, {
 //         headers: {
 //           'Authorization': `Bearer ${accessToken}`,
 //         },
 // 		baseURL: process.env.NEXT_PUBLIC_BASE_URL_API
 //       });
 //       if(data){
 //         return res.status(200).json(data);
 //       }else{
 //         return res.status(400).json(data);
 //       }
 //     } else {
 //       return res.status(400).json({ message: 'create category is failed' });
 //     }
 //   } catch (error) {
 //     // console.error(error);
 //     return res.status(500).json({ message: 'Internal Server Error' });
 //   }
 // }

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6206));
module.exports = __webpack_exports__;

})();