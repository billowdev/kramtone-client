"use strict";
(() => {
var exports = {};
exports.id = 5153;
exports.ids = [5153];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 2913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ clearCookie),
/* harmony export */   "d": () => (/* binding */ setCookie)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

/**
 * This sets `cookie` using the `res` object
 */ const setCookie = (res, name, value, options = {})=>{
    const stringValue = typeof value === "object" ? "j:" + JSON.stringify(value) : String(value);
    if (options.maxAge) {
        options.expires = new Date(Date.now() + options.maxAge);
        options.maxAge = options.maxAge / 1000;
    }
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, String(stringValue), options));
};
const clearCookie = (res, name, path = "/")=>{
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, "", {
        maxAge: -1,
        path
    }));
};


/***/ }),

/***/ 7016:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ acceptCookies)
/* harmony export */ });
/* harmony import */ var _common_utils_cookies_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2913);

async function acceptCookies(req, res) {
    try {
        // Set the cookie_acceptance cookie
        (0,_common_utils_cookies_util__WEBPACK_IMPORTED_MODULE_0__/* .setCookie */ .d)(res, "cookie_acceptance", "true", {
            httpOnly: true,
            secure: "production" !== "development",
            sameSite: "strict",
            path: "/",
            maxAge: 60 * 60 * 24 * 365
        });
        res.status(200).json({
            message: "Cookie consent accepted."
        });
    } catch (error) {
        res.status(400).json({
            message: "An error occurred while setting the cookie."
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7016));
module.exports = __webpack_exports__;

})();