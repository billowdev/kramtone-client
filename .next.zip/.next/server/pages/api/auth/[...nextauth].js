"use strict";
(() => {
var exports = {};
exports.id = 3748;
exports.ids = [3748];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$h": () => (/* binding */ HTTP_METHOD_GET),
/* harmony export */   "CK": () => (/* binding */ HTTP_METHOD_POST),
/* harmony export */   "L": () => (/* binding */ HTTP_METHOD_DELETE),
/* harmony export */   "Wx": () => (/* binding */ ACCESS_TOKEN_KEY),
/* harmony export */   "Z": () => (/* binding */ HTTP_METHOD_PATCH)
/* harmony export */ });
/* unused harmony exports API_REQUEST_SUCCESS, API_REQUEST_FAIL */
const ACCESS_TOKEN_KEY = "access_token";
const HTTP_METHOD_GET = "GET";
const HTTP_METHOD_POST = "POST";
const API_REQUEST_SUCCESS = "success";
const API_REQUEST_FAIL = "fail";
const HTTP_METHOD_DELETE = "DELETE";
const HTTP_METHOD_PATCH = "PATCH";


/***/ }),

/***/ 2913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ clearCookie),
/* harmony export */   "d": () => (/* binding */ setCookie)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

/**
 * This sets `cookie` using the `res` object
 */ const setCookie = (res, name, value, options = {})=>{
    const stringValue = typeof value === "object" ? "j:" + JSON.stringify(value) : String(value);
    if (options.maxAge) {
        options.expires = new Date(Date.now() + options.maxAge);
        options.maxAge = options.maxAge / 1000;
    }
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, String(stringValue), options));
};
const clearCookie = (res, name, path = "/")=>{
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, "", {
        maxAge: -1,
        path
    }));
};


/***/ }),

/***/ 4568:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://www.kramtone.com/service/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8355:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6612);
/* harmony import */ var _common_utils_cookies_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2913);
/* harmony import */ var _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4568);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9344);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__]);
_common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function handler(req, res) {
    if (req.query.nextauth) {
        const signinAction = req.query["nextauth"][0];
        const sessionAction = req.query["nextauth"][0];
        const signOutAction = req.query["nextauth"][0];
        if (req.method === common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .HTTP_METHOD_POST */ .CK && signinAction === "signin") {
            return signin(req, res);
        } else if (req.method === common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .HTTP_METHOD_GET */ .$h && signOutAction === "signout") {
            return signout(req, res);
        } else if (req.method === common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .HTTP_METHOD_GET */ .$h && sessionAction === "session") {
            return getSessionLocalApi(req, res);
        } else {
            return res.status(405).end(`Error: HTTP ${req.method} is not supported for ${req.url}`);
        }
    }
}
async function signin(req, res) {
    try {
        const { username , password  } = req.body;
        // const { data: response } = await httpClient.post(`/users/signin`, { username, password }, {});
        const response = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post(`/users/signin`, {
            username,
            password
        });
        // const response = await axios.post(`/users/signin`, {username, password}, {
        // 	baseURL: process.env.NEXT_PUBLIC_BASE_URL_API
        // });
        // const decryptData = decryptAES<ISignIn>(response.payload)
        // const { token } = decryptData;
        const { token  } = response.data.payload;
        // set the accessToken cookie
        (0,_common_utils_cookies_util__WEBPACK_IMPORTED_MODULE_0__/* .setCookie */ .d)(res, common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .ACCESS_TOKEN_KEY */ .Wx, token, {
            httpOnly: true,
            secure: "production" !== "development",
            sameSite: "strict",
            path: "/"
        });
        // res.status(200).json(decryptData);
        res.json(response.data);
    } catch (error) {
        res.status(400).end();
    }
}
function signout(req, res) {
    (0,_common_utils_cookies_util__WEBPACK_IMPORTED_MODULE_0__/* .clearCookie */ ._)(res, common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .ACCESS_TOKEN_KEY */ .Wx);
    res.json({
        result: "signout successfuly"
    });
}
const getSessionLocalApi = async (req, res)=>{
    try {
        const cookies = cookie__WEBPACK_IMPORTED_MODULE_2___default().parse(req.headers.cookie || "");
        const token = cookies[common_constants_api_constant__WEBPACK_IMPORTED_MODULE_4__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (token) {
            const { data: response  } = await _common_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`/users/session`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            const accessToken = response.payload.refreshToken;
            const session = jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__.decode(accessToken);
            res.status(200).json({
                session,
                accessToken
            });
        } else {
            res.status(400).json({
                success: false,
                msg: "something went wrong!"
            });
        }
    } catch (error) {
        res.status(400).json({
            success: false,
            msg: "something went wrong!"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8355));
module.exports = __webpack_exports__;

})();