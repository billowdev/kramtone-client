"use strict";
(() => {
var exports = {};
exports.id = 2926;
exports.ids = [2926];
exports.modules = {

/***/ 9492:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getCookieAcceptance)
/* harmony export */ });
async function getCookieAcceptance(req, res) {
    try {
        // Get the cookie_acceptance cookie
        const cookieAcceptance = req.cookies.cookie_acceptance;
        if (cookieAcceptance) {
            res.status(200).json({
                message: "Cookie consent accepted.",
                accepted: true
            });
        } else {
            res.status(200).json({
                message: "Cookie consent not accepted.",
                accepted: false
            });
        }
    } catch (error) {
        res.status(400).json({
            message: "An error occurred while getting the cookie."
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9492));
module.exports = __webpack_exports__;

})();